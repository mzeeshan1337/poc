import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import sqlite3 from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new sqlite3('database.sqlite');

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password TEXT,
    bio TEXT,
    avatar_url TEXT,
    role TEXT DEFAULT 'user',
    status TEXT DEFAULT 'active',
    is_verified INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pocs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT,
    slug TEXT UNIQUE,
    vuln_type TEXT,
    severity TEXT,
    description TEXT,
    youtube_url TEXT,
    bounty REAL,
    program TEXT,
    tags TEXT,
    views INTEGER DEFAULT 0,
    status TEXT DEFAULT 'approved',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS writeups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT,
    slug TEXT UNIQUE,
    content TEXT,
    tags TEXT,
    program TEXT,
    bounty REAL,
    severity TEXT,
    views INTEGER DEFAULT 0,
    status TEXT DEFAULT 'approved',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    target_id INTEGER,
    target_type TEXT,
    content TEXT,
    parent_id INTEGER DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(parent_id) REFERENCES comments(id)
  );

  CREATE TABLE IF NOT EXISTS likes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    target_id INTEGER,
    target_type TEXT,
    UNIQUE(user_id, target_id, target_type),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  INSERT OR IGNORE INTO settings (key, value) VALUES ('ads_script', '');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('ads_txt', '');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('announcement', '');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('login_enabled', 'true');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('signup_enabled', 'true');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('maintenance_mode', 'false');
`);

// Migration: Add status column to pocs if it's missing
try {
  db.prepare("ALTER TABLE pocs ADD COLUMN status TEXT DEFAULT 'approved'").run();
  console.log('Added status column to pocs table');
} catch (e: any) {
  if (!e.message.includes('duplicate column name')) {
    console.log('Migration for pocs.status skipped or failed:', e.message);
  }
}

// Migration: Add status column to writeups if it's missing
try {
  db.prepare("ALTER TABLE writeups ADD COLUMN status TEXT DEFAULT 'approved'").run();
  console.log('Added status column to writeups table');
} catch (e: any) {
  if (!e.message.includes('duplicate column name')) {
    console.log('Migration for writeups.status skipped or failed:', e.message);
  }
}

// Migration: Add is_verified column to users if it's missing
try {
  db.prepare('ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0').run();
  console.log('Added is_verified column to users table');
} catch (e: any) {
  if (!e.message.includes('duplicate column name')) {
    console.log('Migration for users.is_verified skipped or failed:', e.message);
  }
}

// Migration: Add severity column to writeups if it's missing
try {
  db.prepare('ALTER TABLE writeups ADD COLUMN severity TEXT').run();
  console.log('Added severity column to writeups table');
} catch (e: any) {
  if (!e.message.includes('duplicate column name')) {
    console.log('Migration for writeups.severity skipped or failed:', e.message);
  }
}

  try {
    const pocCount = db.prepare('SELECT COUNT(*) as count FROM pocs').get().count;
    if (pocCount > 0) {
      console.log('Resetting database for compatibility...');
      db.prepare('DELETE FROM pocs').run();
      db.prepare('DELETE FROM writeups').run();
      db.prepare('DELETE FROM comments').run();
      db.prepare('DELETE FROM likes').run();
      db.prepare("DELETE FROM users WHERE role != 'admin'").run();
    }
  } catch (e) {
    console.log('Database reset skipped or failed (likely empty or new):', e);
  }

// Pre-insert Admin
const adminEmail = 'ranazeeshanbbh@gmail.com';
const adminPassword = 'V+1!xiSEba6-';
const existingAdmin = db.prepare('SELECT * FROM users WHERE email = ?').get(adminEmail);

if (!existingAdmin) {
  const hashedPassword = bcrypt.hashSync(adminPassword, 10);
  db.prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)').run(
    'admin',
    adminEmail,
    hashedPassword,
    'admin'
  );
}

const JWT_SECRET = process.env.JWT_SECRET || 'cyber-secret-key-1337';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { error: 'Too many requests, please try again later.' }
  });

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ error: 'Unauthorized' });

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: 'Forbidden' });
      req.user = user;
      next();
    });
  };

  const optionalAuthenticateToken = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (!token) return next();

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (!err) req.user = user;
      next();
    });
  };

  // --- API Routes ---

  const validateTitle = (title: string) => {
    const words = title.trim().split(/\s+/).length;
    return words <= 15;
  };

  // Auth
  app.post('/api/auth/signup', authLimiter, async (req, res) => {
    try {
      const signupEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('signup_enabled')?.value === 'true';
      const maintenanceMode = db.prepare('SELECT value FROM settings WHERE key = ?').get('maintenance_mode')?.value === 'true';
      if (!signupEnabled || maintenanceMode) {
        const reason = maintenanceMode ? 'The platform is currently under maintenance.' : 'Signup is currently disabled by administrator.';
        return res.status(403).json({ error: reason });
      }

      const { username, email, password, avatar_url } = z.object({
        username: z.string().min(3, "Username must be at least 3 characters").max(20),
        email: z.string().email("Invalid email address"),
        password: z.string().min(8, "Password must be at least 8 characters"),
        avatar_url: z.string().optional()
      }).parse(req.body);

      const existingUser = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email);
      if (existingUser) {
        return res.status(400).json({ error: 'Username or email already exists' });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const result = db.prepare('INSERT INTO users (username, email, password, avatar_url) VALUES (?, ?, ?, ?)').run(username, email, hashedPassword, avatar_url);
      
      const user = { id: result.lastInsertRowid, username, email, role: 'user', is_verified: 0 };
      const token = jwt.sign(user, JWT_SECRET);
      res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none' }).json(user);
    } catch (e: any) {
      if (e instanceof z.ZodError) {
        return res.status(400).json({ error: e.issues[0].message });
      }
      res.status(400).json({ error: e.message || 'Signup failed' });
    }
  });

  app.post('/api/auth/login', authLimiter, async (req, res) => {
    try {
      const loginEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('login_enabled')?.value === 'true';
      const maintenanceMode = db.prepare('SELECT value FROM settings WHERE key = ?').get('maintenance_mode')?.value === 'true';
      const { email, password } = req.body;
      
      const user: any = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
      
      // Allow admins to login even if login is disabled or maintenance mode is on
      if ((!loginEnabled || maintenanceMode) && user?.role !== 'admin') {
        const reason = maintenanceMode ? 'The platform is currently under maintenance.' : 'Login is currently disabled by administrator.';
        return res.status(403).json({ error: reason });
      }

      if (!user || !await bcrypt.compare(password, user.password)) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }
      if (user.status === 'banned') {
        return res.status(403).json({ error: 'Your account has been banned' });
      }
      const payload = { id: user.id, username: user.username, email: user.email, role: user.role, is_verified: user.is_verified };
      const token = jwt.sign(payload, JWT_SECRET);
      res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none' }).json(payload);
    } catch (e) {
      res.status(500).json({ error: 'Login failed' });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    res.clearCookie('token').json({ message: 'Logged out' });
  });

  app.get('/api/auth/me', authenticateToken, (req: any, res) => {
    const user = db.prepare('SELECT id, username, email, bio, avatar_url, role, is_verified, created_at FROM users WHERE id = ?').get(req.user.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  });

  app.put('/api/auth/profile', authenticateToken, (req: any, res) => {
    try {
      const { bio, avatar_url } = req.body;
      db.prepare('UPDATE users SET bio = ?, avatar_url = ? WHERE id = ?').run(bio, avatar_url, req.user.id);
      res.json({ message: 'Profile updated' });
    } catch (e) {
      res.status(500).json({ error: 'Failed to update profile' });
    }
  });

  app.put('/api/auth/password', authenticateToken, async (req: any, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const user: any = db.prepare('SELECT password FROM users WHERE id = ?').get(req.user.id);
      if (!await bcrypt.compare(currentPassword, user.password)) {
        return res.status(401).json({ error: 'Current password incorrect' });
      }
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, req.user.id);
      res.json({ message: 'Password updated' });
    } catch (e) {
      res.status(500).json({ error: 'Failed to update password' });
    }
  });

  // POCs
  app.get('/api/pocs', optionalAuthenticateToken, (req: any, res) => {
    const { sort, type, severity, search, minBounty, page = 1, limit = 30, status } = req.query;
    const userId = req.user?.id || 0;
    const offset = (Number(page) - 1) * Number(limit);
    
    let whereClause = "WHERE u.status = 'active'";
    const params: any[] = [userId];

    if (req.user?.role === 'admin') {
      if (status) {
        whereClause += ' AND p.status = ?';
        params.push(status);
      }
    } else {
      whereClause += ' AND (p.status = "approved" OR p.user_id = ?)';
      params.push(userId);
    }

    if (type) { whereClause += ' AND vuln_type = ?'; params.push(type); }
    if (severity) { whereClause += ' AND severity = ?'; params.push(severity); }
    if (minBounty) { whereClause += ' AND bounty >= ?'; params.push(Number(minBounty)); }
    if (search) { 
      whereClause += ' AND (title LIKE ? OR description LIKE ? OR tags LIKE ?)'; 
      params.push(`%${search}%`, `%${search}%`, `%${search}%`); 
    }

    let orderBy = 'ORDER BY created_at DESC';
    if (sort === 'most_viewed') orderBy = 'ORDER BY views DESC';
    else if (sort === 'most_liked') orderBy = 'ORDER BY likes_count DESC';

    const countQuery = `SELECT COUNT(*) as total FROM pocs p JOIN users u ON p.user_id = u.id ${whereClause}`;
    const total = db.prepare(countQuery).get(...params.slice(1)).total;

    const query = `
      SELECT p.*, u.username as author_name, u.avatar_url as author_avatar, u.is_verified as author_verified,
      (SELECT COUNT(*) FROM likes WHERE target_id = p.id AND target_type = 'poc') as likes_count,
      (SELECT COUNT(*) FROM likes WHERE target_id = p.id AND target_type = 'poc' AND user_id = ?) as is_liked
      FROM pocs p
      JOIN users u ON p.user_id = u.id
      ${whereClause}
      ${orderBy}
      LIMIT ? OFFSET ?
    `;
    params.push(Number(limit), offset);

    const pocs = db.prepare(query).all(...params).map((p: any) => ({ ...p, tags: p.tags || '' }));
    res.json({
      items: pocs,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit))
      }
    });
  });

  app.post('/api/pocs', authenticateToken, (req: any, res) => {
    try {
      const { title, vuln_type, severity, description, youtube_url, bounty, program, tags } = req.body;
      if (!validateTitle(title)) {
        return res.status(400).json({ error: 'PoC Title must not exceed 15 words.' });
      }
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-' + Math.random().toString(36).substring(2, 7);
      
      // Approval logic
      const status = req.user.is_verified === 1 || req.user.role === 'admin' ? 'approved' : 'pending';
      
      const result = db.prepare(`
        INSERT INTO pocs (user_id, title, slug, vuln_type, severity, description, youtube_url, bounty, program, tags, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(req.user.id, title, slug, vuln_type, severity, description, youtube_url, bounty, program, tags, status);
      res.json({ id: result.lastInsertRowid, slug, status });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/pocs/:idOrSlug', optionalAuthenticateToken, (req: any, res) => {
    const idOrSlug = req.params.idOrSlug;
    const isId = /^\d+$/.test(idOrSlug);
    
    if (req.query.skipView !== 'true') {
      if (isId) {
        db.prepare('UPDATE pocs SET views = views + 1 WHERE id = ?').run(idOrSlug);
      } else {
        db.prepare('UPDATE pocs SET views = views + 1 WHERE slug = ?').run(idOrSlug);
      }
    }
    
    const userId = req.user?.id || 0;
    const query = `
      SELECT p.*, u.username as author_name, u.avatar_url as author_avatar, u.is_verified as author_verified,
      (SELECT COUNT(*) FROM likes WHERE target_id = p.id AND target_type = 'poc') as likes_count,
      (SELECT COUNT(*) FROM likes WHERE target_id = p.id AND target_type = 'poc' AND user_id = ?) as is_liked
      FROM pocs p
      JOIN users u ON p.user_id = u.id
      WHERE ${isId ? 'p.id = ?' : 'p.slug = ?'}
    `;
    const poc = db.prepare(query).get(userId, idOrSlug);
    
    if (!poc) return res.status(404).json({ error: 'PoC not found' });
    res.json(poc);
  });

  app.put('/api/pocs/:id', authenticateToken, (req: any, res) => {
    const { title, vuln_type, severity, description, youtube_url, bounty, program, tags } = req.body;
    if (!validateTitle(title)) {
      return res.status(400).json({ error: 'PoC Title must not exceed 15 words.' });
    }
    const poc: any = db.prepare('SELECT user_id FROM pocs WHERE id = ?').get(req.params.id);
    
    if (!poc) return res.status(404).json({ error: 'PoC not found' });
    if (poc.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-' + Math.random().toString(36).substring(2, 7);
    db.prepare(`
      UPDATE pocs 
      SET title = ?, slug = ?, vuln_type = ?, severity = ?, description = ?, youtube_url = ?, bounty = ?, program = ?, tags = ?
      WHERE id = ?
    `).run(title, slug, vuln_type, severity, description, youtube_url, bounty, program, tags, req.params.id);
    
    res.json({ message: 'PoC updated', slug });
  });

  // Writeups
  app.get('/api/writeups', optionalAuthenticateToken, (req: any, res) => {
    const { search, program, minBounty, page = 1, limit = 30, status } = req.query;
    const userId = req.user?.id || 0;
    const offset = (Number(page) - 1) * Number(limit);

    let whereClause = "WHERE u.status = 'active'";
    const params: any[] = [userId];

    if (req.user?.role === 'admin') {
      if (status) {
        whereClause += ' AND w.status = ?';
        params.push(status);
      }
    } else {
      whereClause += ' AND (w.status = "approved" OR w.user_id = ?)';
      params.push(userId);
    }

    if (search) {
      whereClause += ' AND (w.title LIKE ? OR w.content LIKE ? OR w.tags LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (program) {
      whereClause += ' AND w.program LIKE ?';
      params.push(`%${program}%`);
    }
    if (minBounty) {
      whereClause += ' AND w.bounty >= ?';
      params.push(Number(minBounty));
    }

    const countQuery = `SELECT COUNT(*) as total FROM writeups w JOIN users u ON w.user_id = u.id ${whereClause}`;
    const total = db.prepare(countQuery).get(...params.slice(1)).total;

    const query = `
      SELECT w.*, u.username as author_name, u.avatar_url as author_avatar, u.is_verified as author_verified,
      (SELECT COUNT(*) FROM likes WHERE target_id = w.id AND target_type = 'writeup') as likes_count,
      (SELECT COUNT(*) FROM likes WHERE target_id = w.id AND target_type = 'writeup' AND user_id = ?) as is_liked
      FROM writeups w
      JOIN users u ON w.user_id = u.id
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;
    params.push(Number(limit), offset);

    const writeups = db.prepare(query).all(...params).map((w: any) => ({ ...w, tags: w.tags || '' }));
    res.json({
      items: writeups,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / Number(limit))
      }
    });
  });

  app.post('/api/writeups', authenticateToken, (req: any, res) => {
    try {
      const { title, content, tags, program, bounty, severity } = req.body;
      if (!validateTitle(title)) {
        return res.status(400).json({ error: 'Writeup Title must not exceed 15 words.' });
      }
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-' + Math.random().toString(36).substring(2, 7);
      
      // Approval logic
      const status = req.user.is_verified === 1 || req.user.role === 'admin' ? 'approved' : 'pending';
      
      const result = db.prepare('INSERT INTO writeups (user_id, title, slug, content, tags, program, bounty, severity, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)').run(req.user.id, title, slug, content, tags, program, bounty, severity, status);
      res.json({ id: result.lastInsertRowid, slug, status });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/writeups/:idOrSlug', optionalAuthenticateToken, (req: any, res) => {
    const idOrSlug = req.params.idOrSlug;
    const isId = /^\d+$/.test(idOrSlug);

    if (req.query.skipView !== 'true') {
      if (isId) {
        db.prepare('UPDATE writeups SET views = views + 1 WHERE id = ?').run(idOrSlug);
      } else {
        db.prepare('UPDATE writeups SET views = views + 1 WHERE slug = ?').run(idOrSlug);
      }
    }
    
    const userId = req.user?.id || 0;
    const query = `
      SELECT w.*, u.username as author_name, u.avatar_url as author_avatar, u.is_verified as author_verified,
      (SELECT COUNT(*) FROM likes WHERE target_id = w.id AND target_type = 'writeup') as likes_count,
      (SELECT COUNT(*) FROM likes WHERE target_id = w.id AND target_type = 'writeup' AND user_id = ?) as is_liked
      FROM writeups w
      JOIN users u ON w.user_id = u.id
      WHERE ${isId ? 'w.id = ?' : 'w.slug = ?'}
    `;
    const writeup = db.prepare(query).get(userId, idOrSlug);
    
    if (!writeup) return res.status(404).json({ error: 'Writeup not found' });
    res.json(writeup);
  });

  app.put('/api/writeups/:id', authenticateToken, (req: any, res) => {
    const { title, content, tags, program, bounty, severity } = req.body;
    if (!validateTitle(title)) {
      return res.status(400).json({ error: 'Writeup Title must not exceed 15 words.' });
    }
    const writeup: any = db.prepare('SELECT user_id FROM writeups WHERE id = ?').get(req.params.id);
    
    if (!writeup) return res.status(404).json({ error: 'Writeup not found' });
    if (writeup.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-' + Math.random().toString(36).substring(2, 7);
    db.prepare(`
      UPDATE writeups 
      SET title = ?, slug = ?, content = ?, tags = ?, program = ?, bounty = ?, severity = ?
      WHERE id = ?
    `).run(title, slug, content, tags, program, bounty, severity, req.params.id);
    
    res.json({ message: 'Writeup updated', slug });
  });

  // Comments
  app.get('/api/comments/:type/:id', optionalAuthenticateToken, (req: any, res) => {
    const userId = req.user?.id || 0;
    const comments = db.prepare(`
      SELECT c.*, u.username, u.avatar_url, u.is_verified,
      (SELECT COUNT(*) FROM likes WHERE target_id = c.id AND target_type = 'comment') as likes_count,
      (SELECT COUNT(*) FROM likes WHERE target_id = c.id AND target_type = 'comment' AND user_id = ?) > 0 as is_liked
      FROM comments c
      JOIN users u ON c.user_id = u.id
      WHERE target_type = ? AND target_id = ?
      ORDER BY created_at ASC
    `).all(userId, req.params.type, req.params.id);
    res.json(comments);
  });

  app.post('/api/comments', authenticateToken, (req: any, res) => {
    const { target_id, target_type, content, parent_id } = req.body;
    db.prepare('INSERT INTO comments (user_id, target_id, target_type, content, parent_id) VALUES (?, ?, ?, ?, ?)').run(req.user.id, target_id, target_type, content, parent_id || null);
    res.json({ message: 'Comment added' });
  });

  app.delete('/api/comments/:id', authenticateToken, (req: any, res) => {
    const comment: any = db.prepare('SELECT user_id FROM comments WHERE id = ?').get(req.params.id);
    if (!comment) return res.status(404).json({ error: 'Comment not found' });
    
    if (comment.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden' });
    }

    db.prepare('DELETE FROM comments WHERE id = ? OR parent_id = ?').run(req.params.id, req.params.id);
    res.json({ message: 'Comment deleted' });
  });

  // Likes
  app.post('/api/likes', authenticateToken, (req: any, res) => {
    const { target_id, target_type } = req.body;
    try {
      db.prepare('INSERT INTO likes (user_id, target_id, target_type) VALUES (?, ?, ?)').run(req.user.id, target_id, target_type);
      res.json({ liked: true });
    } catch (e) {
      db.prepare('DELETE FROM likes WHERE user_id = ? AND target_id = ? AND target_type = ?').run(req.user.id, target_id, target_type);
      res.json({ liked: false });
    }
  });

  // Programs API
  app.get('/api/programs', (req, res) => {
    try {
      const programsPath = path.resolve(process.cwd(), 'programs.json');
      if (!fs.existsSync(programsPath)) {
        return res.json({ 
          items: [], 
          stats: { total: 0, vdp: 0, bb: 0, platforms: {} },
          pagination: { total: 0, page: 1, limit: 30, totalPages: 1 }
        });
      }
      
      const data = fs.readFileSync(programsPath, 'utf-8');
      let programs = JSON.parse(data);
      
      const { search, platform, type, self_hosted, page = 1, limit = 30 } = req.query;
      
      // Calculate stats BEFORE filtering
      const total = programs.length;
      const vdp = programs.filter((p: any) => !p.bounty_max || Number(p.bounty_max) === 0).length;
      const bb = total - vdp;
      const selfHostedCount = programs.filter((p: any) => p.self_hosted === true).length;
      
      const platformStats: Record<string, number> = {};
      programs.forEach((p: any) => {
        platformStats[p.platform] = (platformStats[p.platform] || 0) + 1;
      });

      // Filtering
      if (search) {
        const searchLower = String(search).toLowerCase();
        programs = programs.filter((p: any) => 
          p.name.toLowerCase().includes(searchLower) || 
          p.platform.toLowerCase().includes(searchLower) ||
          p.scope_tags?.some((t: string) => t.toLowerCase().includes(searchLower))
        );
      }
      
      if (platform) {
        programs = programs.filter((p: any) => p.platform === platform);
      }
      
      if (self_hosted === 'true') {
        programs = programs.filter((p: any) => p.self_hosted === true);
      } else if (self_hosted === 'false') {
        programs = programs.filter((p: any) => p.self_hosted !== true);
      }
      
      if (type === 'vdp') {
        programs = programs.filter((p: any) => !p.bounty_max || Number(p.bounty_max) === 0);
      } else if (type === 'bb') {
        programs = programs.filter((p: any) => p.bounty_max && Number(p.bounty_max) > 0);
      }
      
      const totalFiltered = programs.length;
      const offset = (Number(page) - 1) * Number(limit);
      const paginatedItems = programs.slice(offset, offset + Number(limit));
      
      res.json({
        items: paginatedItems,
        stats: { total, vdp, bb, selfHosted: selfHostedCount, platforms: platformStats },
        pagination: {
          total: totalFiltered,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(totalFiltered / Number(limit))
        }
      });
    } catch (e) {
      console.error('Error loading programs:', e);
      res.status(500).json({ error: 'Failed to load programs' });
    }
  });

  app.post('/api/programs', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      const programsPath = path.resolve(process.cwd(), 'programs.json');
      let programs = [];
      if (fs.existsSync(programsPath)) {
        programs = JSON.parse(fs.readFileSync(programsPath, 'utf-8'));
      }
      
      const newProgram = req.body;
      // Basic validation
      if (!newProgram.name || !newProgram.link) {
        return res.status(400).json({ error: 'Name and link are required' });
      }
      
      programs.unshift({
        ...newProgram,
        handle: Math.random().toString(36).substring(2, 15),
        date_launched: new Date().toISOString().split('T')[0],
        up_votes: 0,
        down_votes: 0,
        total_votes: 0,
        vote_ratio: 0,
        net_score: 0,
        self_hosted: !!newProgram.self_hosted
      });
      
      fs.writeFileSync(programsPath, JSON.stringify(programs));
      res.json({ message: 'Program added successfully' });
    } catch (e) {
      res.status(500).json({ error: 'Failed to add program' });
    }
  });

  app.delete('/api/programs/:handle', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      const programsPath = path.resolve(process.cwd(), 'programs.json');
      if (!fs.existsSync(programsPath)) return res.status(404).json({ error: 'Not found' });
      
      let programs = JSON.parse(fs.readFileSync(programsPath, 'utf-8'));
      const initialLength = programs.length;
      programs = programs.filter((p: any) => p.handle !== req.params.handle);
      
      if (programs.length === initialLength) {
        return res.status(404).json({ error: 'Program not found' });
      }
      
      fs.writeFileSync(programsPath, JSON.stringify(programs));
      res.json({ message: 'Program deleted successfully' });
    } catch (e) {
      res.status(500).json({ error: 'Failed to delete program' });
    }
  });

  // Leaderboard
  app.get('/api/leaderboard', (req, res) => {
    const topHunters = db.prepare(`
      SELECT u.id, u.username, u.avatar_url, u.is_verified,
      (SELECT COUNT(*) FROM pocs WHERE user_id = u.id) as poc_count,
      (SELECT COUNT(*) FROM writeups WHERE user_id = u.id) as writeup_count,
      (
        (SELECT COUNT(*) FROM likes l JOIN pocs p ON l.target_id = p.id WHERE p.user_id = u.id AND l.target_type = 'poc') +
        (SELECT COUNT(*) FROM likes l JOIN writeups w ON l.target_id = w.id WHERE w.user_id = u.id AND l.target_type = 'writeup')
      ) as total_likes
      FROM users u
      WHERE u.status = 'active'
      ORDER BY total_likes DESC LIMIT 50
    `).all();
    res.json(topHunters);
  });

  // User Profile
  app.get('/api/users/:identifier', optionalAuthenticateToken, (req: any, res) => {
    const { identifier } = req.params;
    let user;
    
    // Try to find by username first
    user = db.prepare('SELECT id, username, bio, avatar_url, created_at, status, is_verified FROM users WHERE username = ?').get(identifier);
    
    // If not found and identifier is a number, try to find by ID (for backward compatibility if needed)
    if (!user && /^\d+$/.test(identifier)) {
      user = db.prepare('SELECT id, username, bio, avatar_url, created_at, status, is_verified FROM users WHERE id = ?').get(identifier);
    }

    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user.status === 'banned') return res.status(403).json({ error: 'User is banned' });
    
    const userId = req.user?.id || 0;
    const userPocs = db.prepare("SELECT * FROM pocs WHERE user_id = ? AND (status = 'approved' OR user_id = ?) ORDER BY created_at DESC").all(user.id, userId);
    const userWriteups = db.prepare("SELECT * FROM writeups WHERE user_id = ? AND (status = 'approved' OR user_id = ?) ORDER BY created_at DESC").all(user.id, userId);
    
    // Calculate rank
    const rankings = db.prepare(`
      SELECT u.id,
      (
        (SELECT COUNT(*) FROM likes l JOIN pocs p ON l.target_id = p.id WHERE p.user_id = u.id AND l.target_type = 'poc') +
        (SELECT COUNT(*) FROM likes l JOIN writeups w ON l.target_id = w.id WHERE w.user_id = u.id AND l.target_type = 'writeup')
      ) as total_likes
      FROM users u
      WHERE u.status = 'active'
      ORDER BY total_likes DESC
    `).all();
    
    const rank = rankings.findIndex((r: any) => r.id === user.id) + 1;

    res.json({ 
      ...user, 
      pocs: userPocs, 
      writeups: userWriteups,
      rank: rank > 0 ? rank : 'N/A',
      poc_count: userPocs.length,
      writeup_count: userWriteups.length,
      total_likes: rankings.find((r: any) => r.id === user.id)?.total_likes || 0
    });
  });

  // Admin
  app.get('/api/admin/stats', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const stats = {
      users: db.prepare('SELECT COUNT(*) as count FROM users').get().count,
      pocs: db.prepare('SELECT COUNT(*) as count FROM pocs').get().count,
      writeups: db.prepare('SELECT COUNT(*) as count FROM writeups').get().count,
      pendingPocs: db.prepare("SELECT COUNT(*) as count FROM pocs WHERE status = 'pending'").get().count,
      pendingWriteups: db.prepare("SELECT COUNT(*) as count FROM writeups WHERE status = 'pending'").get().count
    };
    res.json(stats);
  });

  app.get('/api/admin/users', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const users = db.prepare('SELECT id, username, email, role, status, is_verified, created_at FROM users').all();
    res.json(users);
  });

  app.post('/api/admin/users/:id/status', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { status } = req.body;
    db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, req.params.id);
    res.json({ message: 'User status updated' });
  });

  app.post('/api/admin/users/:id/verify', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { is_verified } = req.body;
    db.prepare('UPDATE users SET is_verified = ? WHERE id = ?').run(is_verified ? 1 : 0, req.params.id);
    res.json({ message: 'User verification updated' });
  });

  app.get('/api/admin/ads', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const script = db.prepare('SELECT value FROM settings WHERE key = ?').get('ads_script')?.value || '';
    const adsTxt = db.prepare('SELECT value FROM settings WHERE key = ?').get('ads_txt')?.value || '';
    const announcement = db.prepare('SELECT value FROM settings WHERE key = ?').get('announcement')?.value || '';
    const loginEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('login_enabled')?.value === 'true';
    const signupEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('signup_enabled')?.value === 'true';
    const maintenanceMode = db.prepare('SELECT value FROM settings WHERE key = ?').get('maintenance_mode')?.value === 'true';
    res.json({ script, adsTxt, announcement, loginEnabled, signupEnabled, maintenanceMode });
  });

  app.post('/api/admin/ads', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { script, adsTxt, announcement, loginEnabled, signupEnabled, maintenanceMode } = req.body;
    if (script !== undefined) db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('ads_script', script);
    if (adsTxt !== undefined) db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('ads_txt', adsTxt);
    if (announcement !== undefined) db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('announcement', announcement);
    if (loginEnabled !== undefined) db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('login_enabled', String(loginEnabled));
    if (signupEnabled !== undefined) db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('signup_enabled', String(signupEnabled));
    if (maintenanceMode !== undefined) db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run('maintenance_mode', String(maintenanceMode));
    res.json({ message: 'Settings updated' });
  });

  // Admin approval endpoints
  app.get('/api/admin/pending-pocs', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const pocs = db.prepare(`
      SELECT p.*, u.username as author_name, u.avatar_url as author_avatar, u.is_verified as author_verified
      FROM pocs p
      JOIN users u ON p.user_id = u.id
      WHERE p.status = 'pending'
      ORDER BY p.created_at DESC
    `).all();
    res.json(pocs);
  });

  app.get('/api/admin/pending-writeups', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const writeups = db.prepare(`
      SELECT w.*, u.username as author_name, u.avatar_url as author_avatar, u.is_verified as author_verified
      FROM writeups w
      JOIN users u ON w.user_id = u.id
      WHERE w.status = 'pending'
      ORDER BY w.created_at DESC
    `).all();
    res.json(writeups);
  });

  app.post('/api/admin/pocs/:id/status', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { status } = req.body;
    if (!['approved', 'rejected', 'pending'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    db.prepare('UPDATE pocs SET status = ? WHERE id = ?').run(status, req.params.id);
    res.json({ message: `PoC status updated to ${status}` });
  });

  app.post('/api/admin/writeups/:id/status', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { status } = req.body;
    if (!['approved', 'rejected', 'pending'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    db.prepare('UPDATE writeups SET status = ? WHERE id = ?').run(status, req.params.id);
    res.json({ message: `Writeup status updated to ${status}` });
  });

  app.get('/api/settings/public', (req, res) => {
    const loginEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('login_enabled')?.value === 'true';
    const signupEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('signup_enabled')?.value === 'true';
    const maintenanceMode = db.prepare('SELECT value FROM settings WHERE key = ?').get('maintenance_mode')?.value === 'true';
    const announcement = db.prepare('SELECT value FROM settings WHERE key = ?').get('announcement')?.value || '';
    res.json({ loginEnabled, signupEnabled, maintenanceMode, announcement });
  });

  app.get('/ads.txt', (req, res) => {
    const adsTxt = db.prepare('SELECT value FROM settings WHERE key = ?').get('ads_txt')?.value || '';
    res.set('Content-Type', 'text/plain').send(adsTxt);
  });

  app.get('/robots.txt', (req, res) => {
    const robotsTxt = `User-agent: *
Allow: /
Allow: /writeups
Allow: /leaderboard
Allow: /poc/
Allow: /profile/
Allow: /programs
Allow: /llms.txt
Disallow: /login
Disallow: /signup
Disallow: /submit
Disallow: /submit-writeup
Disallow: /edit-writeup/
Disallow: /edit-poc/`;
    res.set('Content-Type', 'text/plain').send(robotsTxt);
  });

  app.delete('/api/admin/pocs/:id', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      db.transaction(() => {
        db.prepare("DELETE FROM likes WHERE target_id = ? AND target_type = 'poc'").run(req.params.id);
        db.prepare("DELETE FROM comments WHERE target_id = ? AND target_type = 'poc'").run(req.params.id);
        db.prepare('DELETE FROM pocs WHERE id = ?').run(req.params.id);
      })();
      res.json({ message: 'PoC deleted' });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.delete('/api/admin/writeups/:id', authenticateToken, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      db.transaction(() => {
        db.prepare("DELETE FROM likes WHERE target_id = ? AND target_type = 'writeup'").run(req.params.id);
        db.prepare("DELETE FROM comments WHERE target_id = ? AND target_type = 'writeup'").run(req.params.id);
        db.prepare('DELETE FROM writeups WHERE id = ?').run(req.params.id);
      })();
      res.json({ message: 'Writeup deleted' });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Production Static File Serving
  const distPath = path.resolve(__dirname, 'dist');
  
  // Serve static assets from the dist folder
  app.use(express.static(distPath, { index: false }));

  // Fallback route for React Router (SPA)
  app.get('*', (req, res) => {
    try {
      const adsScript = db.prepare('SELECT value FROM settings WHERE key = ?').get('ads_script')?.value || '';
      const indexPath = path.join(distPath, 'index.html');
      
      if (fs.existsSync(indexPath)) {
        let html = fs.readFileSync(indexPath, 'utf-8');
        // Inject dynamic ads script before </head>
        html = html.replace('</head>', `${adsScript}</head>`);
        res.send(html);
      } else {
        res.status(404).send('Production build not found. Please run "npm run build" first.');
      }
    } catch (e) {
      console.error('Error serving index.html:', e);
      res.status(500).send('Internal Server Error');
    }
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Production server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
