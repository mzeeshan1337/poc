import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Navbar from './components/Navbar';
import AnnouncementModal from './components/AnnouncementModal';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import SubmitPoC from './pages/SubmitPoC';
import PoCDetail from './pages/PoCDetail';
import Profile from './pages/Profile';
import Writeups from './pages/Writeups';
import WriteupDetail from './pages/WriteupDetail';
import SubmitWriteup from './pages/SubmitWriteup';
import EditWriteup from './pages/EditWriteup';
import EditPoC from './pages/EditPoC';
import Leaderboard from './pages/Leaderboard';
import Programs from './pages/Programs';
import NotFound from './pages/NotFound';

import Admin from './pages/Admin';
import About from './pages/About';
import Contact from './pages/Contact';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Disclaimer from './pages/Disclaimer';
import CookiePolicy from './pages/CookiePolicy';
import BecomeVerified from './pages/BecomeVerified';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';
import MaintenanceGuard from './components/MaintenanceGuard';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <ScrollToTop />
        <div className="min-h-screen bg-[#0a0b10] text-zinc-100 selection:bg-orange-500/30 selection:text-orange-500">
          <AnnouncementModal />
          <Navbar />
          <main className="mx-auto max-w-[1600px] px-4 py-8 sm:px-6 lg:px-12">
            <MaintenanceGuard>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/submit" element={<SubmitPoC />} />
                <Route path="/poc/:id" element={<PoCDetail />} />
                <Route path="/profile/:username" element={<Profile />} />
                <Route path="/writeups" element={<Writeups />} />
                <Route path="/writeup/:id" element={<WriteupDetail />} />
                <Route path="/edit-writeup/:id" element={<EditWriteup />} />
                <Route path="/edit-poc/:id" element={<EditPoC />} />
                <Route path="/submit-writeup" element={<SubmitWriteup />} />
                <Route path="/leaderboard" element={<Leaderboard />} />
                <Route path="/programs" element={<Programs />} />
                <Route path="/admin" element={<Admin />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/disclaimer" element={<Disclaimer />} />
                <Route path="/cookies" element={<CookiePolicy />} />
                <Route path="/become-verified" element={<BecomeVerified />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </MaintenanceGuard>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}
