import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getYouTubeThumbnail(url: string) {
  try {
    const videoId = url.split('v=')[1]?.split('&')[0] || url.split('be/')[1]?.split('?')[0];
    if (!videoId) return 'https://picsum.photos/seed/cyber/800/450';
    // Use hqdefault as it's more reliable than maxresdefault
    return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
  } catch (e) {
    return 'https://picsum.photos/seed/cyber/800/450';
  }
}

export function formatBounty(amount: number | null) {
  if (!amount) return 'N/A';
  return new Intl.NumberFormat('en-US', { 
    style: 'currency', 
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0 
  }).format(amount);
}
