import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Shield, Youtube, AlertTriangle, Tag, DollarSign, FileText, Save, ArrowLeft } from 'lucide-react';

export default function EditPoC() {
  const { id } = useParams();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    vuln_type: 'XSS',
    severity: 'Medium',
    description: '',
    youtube_url: '',
    bounty: '',
    program: '',
    tags: ''
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
      return;
    }

    const fetchPoC = async () => {
      try {
        const res = await fetch(`/api/pocs/${id}?skipView=true`);
        if (res.status === 404) {
          navigate('/');
          return;
        }
        if (!res.ok) throw new Error('PoC not found');
        const data = await res.json();
        
        // Security check: only author or admin can edit
        if (user && data.user_id !== user.id && user.role !== 'admin') {
          navigate(`/poc/${id}`);
          return;
        }

        setFormData({
          title: data.title,
          vuln_type: data.vuln_type,
          severity: data.severity,
          description: data.description,
          youtube_url: data.youtube_url,
          bounty: data.bounty?.toString() || '',
          program: data.program || '',
          tags: data.tags || ''
        });
      } catch (e) {
        console.error(e);
        navigate('/');
      } finally {
        setLoading(false);
      }
    };

    if (user) fetchPoC();
  }, [id, user, authLoading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const titleWords = formData.title.trim().split(/\s+/).length;
    if (titleWords > 15) {
      alert('PoC Title must not exceed 15 words.');
      return;
    }

    setSaving(true);
    try {
      const res = await fetch(`/api/pocs/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          bounty: formData.bounty ? parseFloat(formData.bounty) : null
        }),
      });
      const data = await res.json();
      if (res.ok) {
        navigate(`/poc/${data.slug || id}`);
      } else {
        alert(data.error || 'Failed to update PoC');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-brand border-t-transparent"></div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="mx-auto max-w-[1400px] pb-20">
      <button 
        onClick={() => navigate(-1)}
        className="mb-8 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.2em] text-zinc-500 hover:text-white transition-colors"
      >
        <ArrowLeft size={14} />
        Back
      </button>

      <div className="mb-12 flex items-center gap-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-[1.5rem] bg-brand/10 border border-brand/20 text-brand shadow-[0_0_30px_rgba(242,125,38,0.1)]">
          <Shield size={32} />
        </div>
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase">EDIT <span className="text-brand">PROOF OF CONCEPT</span></h1>
          <p className="text-zinc-500 text-lg">Update your technical discovery details.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="premium-card p-10 md:p-16 space-y-10">
        <div className="space-y-8">
          <div className="space-y-3">
            <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
              <FileText size={14} className="text-brand" />
              PoC Title
            </label>
            <input
              required
              placeholder="e.g. Stored XSS on Profile Page via Avatar Upload"
              className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <AlertTriangle size={14} className="text-brand" />
                Vulnerability Type
              </label>
              <div className="relative">
                <select
                  className="w-full appearance-none rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                  value={formData.vuln_type}
                  onChange={(e) => setFormData({ ...formData, vuln_type: e.target.value })}
                >
                  <option value="XSS">XSS</option>
                  <option value="IDOR">IDOR</option>
                  <option value="SQLi">SQLi</option>
                  <option value="SSRF">SSRF</option>
                  <option value="RCE">RCE</option>
                  <option value="LFI">LFI</option>
                  <option value="Business Logic">Business Logic</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <Shield size={14} className="text-brand" />
                Severity
              </label>
              <div className="relative">
                <select
                  className="w-full appearance-none rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                  value={formData.severity}
                  onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical</option>
                </select>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
              <Tag size={14} className="text-brand" />
              Target Program
            </label>
            <input
              required
              placeholder="e.g. Google, Facebook, Private Program"
              className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
              value={formData.program}
              onChange={(e) => setFormData({ ...formData, program: e.target.value })}
            />
          </div>

          <div className="space-y-3">
            <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
              <Youtube size={14} className="text-brand" />
              YouTube Video Link
            </label>
            <div className="relative">
              <Youtube className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
              <input
                required
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full rounded-2xl border border-white/5 bg-black/40 py-5 pr-5 pl-14 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                value={formData.youtube_url}
                onChange={(e) => setFormData({ ...formData, youtube_url: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
              <FileText size={14} className="text-brand" />
              Description
            </label>
            <textarea
              required
              rows={8}
              placeholder="Provide a detailed explanation of the vulnerability and steps to reproduce..."
              className="w-full rounded-2xl border border-white/5 bg-black/40 p-6 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all resize-none"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <DollarSign size={14} className="text-brand" />
                Bounty Amount (Optional)
              </label>
              <div className="relative">
                <DollarSign className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
                <input
                  type="number"
                  placeholder="0"
                  className="w-full rounded-2xl border border-white/5 bg-black/40 py-5 pr-5 pl-14 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                  value={formData.bounty}
                  onChange={(e) => setFormData({ ...formData, bounty: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <Tag size={14} className="text-brand" />
                Tags (Comma separated)
              </label>
              <div className="relative">
                <Tag className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
                <input
                  placeholder="bugbounty, web, security"
                  className="w-full rounded-2xl border border-white/5 bg-black/40 py-5 pr-5 pl-14 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                />
              </div>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="btn-primary w-full py-6 text-lg flex items-center justify-center gap-3"
        >
          <Save size={24} />
          {saving ? 'UPDATING...' : 'UPDATE PROOF OF CONCEPT'}
        </button>
      </form>
    </div>
  );
}
