import { useState, useEffect } from 'react';
import { Search, Filter, SlidersHorizontal, PlusCircle, DollarSign } from 'lucide-react';
import PocCard from '../components/PocCard';
import { Link } from 'react-router-dom';

export default function Home() {
  const [pocs, setPocs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [severity, setSeverity] = useState('');
  const [sort, setSort] = useState('newest');
  const [minBounty, setMinBounty] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchPocs = async () => {
    setLoading(true);
    const params = new URLSearchParams({
      search,
      type,
      severity,
      sort,
      minBounty,
      page: page.toString(),
      limit: '30'
    });
    const res = await fetch(`/api/pocs?${params}`);
    const data = await res.json();
    setPocs(data.items);
    setTotalPages(data.pagination.totalPages);
    setLoading(false);
  };

  useEffect(() => {
    const timer = setTimeout(fetchPocs, 300);
    return () => clearTimeout(timer);
  }, [search, type, severity, sort, minBounty, page]);

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-[#0a0a0a] border border-white/5 p-8 md:p-20">
        <div className="relative z-10 max-w-5xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-brand mb-8 border border-brand/20">
            <span className="relative flex h-2 w-2">
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand"></span>
            </span>
            Platform Live
          </div>
          <h1 className="text-4xl font-black tracking-tighter text-white sm:text-5xl md:text-8xl leading-[1] sm:leading-[0.9]">
            Archive Your <span className="text-brand">Security Research.</span>
          </h1>
          <p className="mt-6 sm:mt-8 text-lg sm:text-xl text-zinc-400 leading-relaxed max-w-2xl">
            A platform for security researchers to share Proof-of-Concepts, vulnerability write-ups, and technical discoveries.
          </p>
          <div className="mt-10 sm:mt-12 flex flex-col sm:flex-row gap-4 sm:gap-6">
            <Link to="/submit" className="btn-primary w-full sm:w-auto text-center">
              SUBMIT RESEARCH
            </Link>
            <Link to="/writeups" className="btn-secondary w-full sm:w-auto text-center">
              BROWSE WRITEUPS
            </Link>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand/10 to-transparent pointer-events-none" />
        <div className="absolute -right-20 -top-20 h-[30rem] w-[30rem] rounded-full bg-brand/5 blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-full h-px bg-gradient-to-r from-transparent via-brand/20 to-transparent" />
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between glass p-6 rounded-3xl border-white/5">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
          <input
            type="text"
            placeholder="Search vulnerabilities, tags, or hunters..."
            className="w-full rounded-2xl border border-white/5 bg-black/40 py-4 pr-5 pl-14 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 col-span-2 sm:col-auto">
            <Filter size={16} className="text-zinc-500" />
            <select 
              className="w-full sm:w-auto rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-xs font-bold uppercase tracking-wider text-zinc-400 focus:outline-none focus:border-brand/50 cursor-pointer"
              value={type}
              onChange={(e) => setType(e.target.value)}
            >
              <option value="">All Types</option>
              <option value="XSS">XSS</option>
              <option value="IDOR">IDOR</option>
              <option value="SQLi">SQLi</option>
              <option value="SSRF">SSRF</option>
              <option value="RCE">RCE</option>
              <option value="LFI">LFI</option>
              <option value="Business Logic">Business Logic</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <select 
            className="rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-xs font-bold uppercase tracking-wider text-zinc-400 focus:outline-none focus:border-brand/50 cursor-pointer"
            value={severity}
            onChange={(e) => setSeverity(e.target.value)}
          >
            <option value="">All Severities</option>
            <option value="Low">Low</option>
            <option value="Medium">Medium</option>
            <option value="High">High</option>
            <option value="Critical">Critical</option>
          </select>

          <select 
            className="rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-xs font-bold uppercase tracking-wider text-zinc-400 focus:outline-none focus:border-brand/50 cursor-pointer"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="newest">Newest First</option>
            <option value="most_viewed">Most Viewed</option>
            <option value="most_liked">Most Liked</option>
          </select>

          <div className="flex items-center gap-2 col-span-2 sm:col-auto">
            <DollarSign size={16} className="text-zinc-500" />
            <input
              type="number"
              placeholder="Min Bounty..."
              className="w-full sm:w-24 rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-xs font-bold text-white focus:border-brand/50 focus:outline-none transition-all"
              value={minBounty}
              onChange={(e) => setMinBounty(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Feed */}
      {loading ? (
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-80 animate-pulse rounded-3xl bg-white/[0.02] border border-white/5" />
          ))}
        </div>
      ) : pocs.length > 0 ? (
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {pocs.map((poc: any) => (
            <PocCard key={poc.id} poc={poc} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-32 text-center glass rounded-[3rem]">
          <div className="mb-6 rounded-full bg-white/5 p-8 text-zinc-700">
            <Search size={64} strokeWidth={1} />
          </div>
          <h3 className="text-2xl font-bold text-white">No research found</h3>
          <p className="text-zinc-500 mt-2 max-w-xs">Try adjusting your search parameters or filters to find what you're looking for.</p>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-12 flex items-center justify-center gap-2">
          <button
            onClick={() => handlePageChange(Math.max(1, page - 1))}
            disabled={page === 1}
            className="btn-secondary px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          <div className="flex items-center gap-2 px-4">
            <span className="text-sm font-bold text-white">Page {page}</span>
            <span className="text-sm text-zinc-500">of {totalPages}</span>
          </div>
          <button
            onClick={() => handlePageChange(Math.min(totalPages, page + 1))}
            disabled={page === totalPages}
            className="btn-secondary px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
