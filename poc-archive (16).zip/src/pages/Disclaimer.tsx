import { motion } from 'motion/react';
import { AlertCircle, ShieldAlert, Info, ExternalLink } from 'lucide-react';

export default function Disclaimer() {
  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase">DISCLAIMER</h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Important information regarding the content on our platform.</p>
        </div>

        <div className="glass p-10 rounded-[3rem] border-white/5 space-y-10">
          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <ShieldAlert size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Educational Purposes Only</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              The information and Proof-of-Concepts (PoCs) provided on this platform are for educational and ethical research purposes only. We do not condone or encourage any illegal activities or unauthorized access to systems.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <AlertCircle size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">No Warranties</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              The materials on this platform are provided on an 'as is' basis. We make no warranties, expressed or implied, and hereby disclaim and negate all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <ExternalLink size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">External Links</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              Our platform may contain links to external websites that are not provided or maintained by or in any way affiliated with us. Please note that we do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <ShieldAlert size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Content Monitoring & Permissions</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              All content on this platform is actively monitored by administrators. We reserve the right to immediately remove any content that violates our platform rules or ethical guidelines. Furthermore, all PoCs and writeups are published only after obtaining explicit permissions from the relevant bug bounty programs or organizations involved.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Info size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Use at Your Own Risk</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              Any action you take upon the information you find on this platform is strictly at your own risk. We will not be liable for any losses and/or damages in connection with the use of our platform.
            </p>
          </section>

          <div className="pt-10 border-t border-white/5 text-center">
            <p className="text-zinc-600 text-sm">Last updated: March 12, 2026</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
