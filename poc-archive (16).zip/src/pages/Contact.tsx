import { motion } from 'motion/react';
import { Mail, MapPin } from 'lucide-react';

export default function Contact() {
  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter">CONTACT <span className="text-brand">US</span></h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Have questions or feedback? We'd love to hear from you.</p>
        </div>

        <div className="flex justify-center">
          <div className="glass p-12 rounded-[3rem] border-white/5 text-center space-y-6 max-w-md w-full">
            <div className="h-16 w-16 rounded-2xl bg-brand/10 flex items-center justify-center text-brand mx-auto">
              <Mail size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white">Email Us</h3>
            <p className="text-zinc-400 leading-relaxed">
              For any inquiries, support requests, or feedback, please reach out to us directly via email. Our team typically responds within 24-48 hours.
            </p>
            <div className="pt-4">
              <a 
                href="mailto:contact@zeeshan.id" 
                className="text-xl font-black text-brand hover:underline tracking-tight"
              >
                contact@zeeshan.id
              </a>
            </div>
          </div>
        </div>

        <div className="text-center space-y-8">
          <h2 className="text-3xl font-black text-white tracking-tight uppercase">GET IN TOUCH</h2>
          <p className="text-zinc-400 leading-relaxed max-w-2xl mx-auto">
            Our team is dedicated to providing the best experience for our community. Whether you're reporting a bug on our platform, inquiring about partnerships, or need help with your account, we're here to help.
          </p>
          <div className="flex flex-col items-center gap-4 text-zinc-500">
            <div className="flex items-center gap-4">
              <Mail className="text-brand" size={20} />
              <span>contact@zeeshan.id</span>
            </div>
            <div className="flex items-center gap-4">
              <MapPin className="text-brand" size={20} />
              <span>Global Security Community</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
