import { motion } from 'motion/react';
import { Cookie, Shield, Info, Settings } from 'lucide-react';

export default function CookiePolicy() {
  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase">COOKIE <span className="text-brand">POLICY</span></h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Transparency about how we use cookies to enhance your experience.</p>
        </div>

        <div className="glass p-10 rounded-[3rem] border-white/5 space-y-10">
          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Cookie size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">What are Cookies?</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              Cookies are small text files that are placed on your device by websites that you visit. They are widely used to make websites work, or work more efficiently, as well as to provide information to the owners of the site.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Shield size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">How We Use Cookies</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              We use cookies for several reasons. Some cookies are required for technical reasons in order for our platform to operate, and we refer to these as "essential" or "strictly necessary" cookies. Other cookies also enable us to track and target the interests of our users to enhance the experience on our platform.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Info size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Types of Cookies We Use</h2>
            </div>
            <div className="space-y-6">
              <div>
                <h3 className="text-white font-bold mb-2">Essential Cookies</h3>
                <p className="text-zinc-400">These cookies are strictly necessary to provide you with services available through our platform and to use some of its features, such as access to secure areas.</p>
              </div>
              <div>
                <h3 className="text-white font-bold mb-2">Performance and Functionality Cookies</h3>
                <p className="text-zinc-400">These cookies are used to enhance the performance and functionality of our platform but are non-essential to their use. However, without these cookies, certain functionality may become unavailable.</p>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Settings size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Managing Cookies</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              Most web browsers allow some control of most cookies through the browser settings. To find out more about cookies, including how to see what cookies have been set, visit <a href="https://www.aboutcookies.org" className="text-brand hover:underline">www.aboutcookies.org</a> or <a href="https://www.allaboutcookies.org" className="text-brand hover:underline">www.allaboutcookies.org</a>.
            </p>
          </section>

          <div className="pt-10 border-t border-white/5 text-center">
            <p className="text-zinc-600 text-sm">Last updated: March 12, 2026</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
