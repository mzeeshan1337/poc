import { Hammer } from 'lucide-react';

export default function Maintenance() {
  return (
    <div className="flex min-h-[80vh] flex-col items-center justify-center text-center px-4">
      <div className="mb-8 flex h-24 w-24 items-center justify-center rounded-[2.5rem] bg-orange-500/10 text-orange-500 shadow-[0_0_50px_rgba(242,125,38,0.1)] border border-orange-500/20">
        <Hammer size={48} className="animate-pulse" />
      </div>
      <h1 className="text-5xl font-black text-white tracking-tighter uppercase mb-4">
        Under <span className="text-orange-500">Maintenance</span>
      </h1>
      <p className="max-w-md text-zinc-500 text-lg font-medium leading-relaxed">
        We're currently performing some scheduled upgrades to improve your experience. 
        We'll be back online shortly. Thank you for your patience!
      </p>
      <div className="mt-12 flex items-center gap-3 text-zinc-600 text-sm font-bold uppercase tracking-widest">
        <span className="h-2 w-2 rounded-full bg-orange-500 animate-ping" />
        System Upgrade in Progress
      </div>
    </div>
  );
}
