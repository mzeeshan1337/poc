import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Trophy, User, ThumbsUp, Shield, Award } from 'lucide-react';
import VerifiedBadge from '../components/VerifiedBadge';

export default function Leaderboard() {
  const [hunters, setHunters] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      const res = await fetch('/api/leaderboard');
      const data = await res.json();
      setHunters(data);
      setLoading(false);
    };
    fetchLeaderboard();
  }, []);

  return (
    <div className="mx-auto max-w-[1400px] space-y-8">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500/20 text-orange-500">
          <Trophy size={32} />
        </div>
        <h1 className="text-4xl font-black text-white">Top <span className="text-orange-500">Hunters</span></h1>
        <p className="mt-2 text-zinc-500">Recognizing the most impactful researchers in our community.</p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-20 animate-pulse rounded-2xl bg-white/5" />
          ))}
        </div>
      ) : (
        <div className="overflow-x-auto rounded-3xl border border-white/5 bg-[#15171e] shadow-2xl">
          <div className="min-w-[800px]">
            <div className="grid grid-cols-12 border-b border-white/5 bg-white/5 px-6 py-4 text-xs font-bold uppercase tracking-wider text-zinc-500">
              <div className="col-span-1">Rank</div>
              <div className="col-span-5">Researcher</div>
              <div className="col-span-2 text-center">PoCs</div>
              <div className="col-span-2 text-center">Writeups</div>
              <div className="col-span-2 text-right">Total Likes</div>
            </div>
            
            <div className="divide-y divide-white/5">
              {hunters.slice(0, 50).map((hunter: any, index: number) => (
                <Link 
                  key={hunter.id} 
                  to={`/profile/${hunter.username}`}
                  className="grid grid-cols-12 items-center px-6 py-4 transition-colors hover:bg-white/5"
                >
                  <div className="col-span-1">
                    {index === 0 ? (
                      <Award className="text-yellow-500" size={24} />
                    ) : index === 1 ? (
                      <Award className="text-zinc-400" size={24} />
                    ) : index === 2 ? (
                      <Award className="text-orange-700" size={24} />
                    ) : (
                      <span className="text-lg font-bold text-zinc-600">#{index + 1}</span>
                    )}
                  </div>
                  
                  <div className="col-span-5 flex items-center gap-4">
                    <div className="h-10 w-10 overflow-hidden rounded-xl border border-white/10 bg-zinc-800">
                      <img 
                        src={hunter.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${hunter.username}`} 
                        className="h-full w-full object-cover"
                        alt={hunter.username}
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{hunter.username}</span>
                      {hunter.is_verified === 1 && <VerifiedBadge size={14} />}
                    </div>
                  </div>
                  
                  <div className="col-span-2 text-center">
                    <span className="rounded-md bg-white/5 px-2 py-1 text-xs font-bold text-zinc-400">
                      {hunter.poc_count}
                    </span>
                  </div>

                  <div className="col-span-2 text-center">
                    <span className="rounded-md bg-white/5 px-2 py-1 text-xs font-bold text-zinc-400">
                      {hunter.writeup_count}
                    </span>
                  </div>
                  
                  <div className="col-span-2 flex items-center justify-end gap-2 text-orange-500">
                    <ThumbsUp size={16} />
                    <span className="text-lg font-black">{hunter.total_likes}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
