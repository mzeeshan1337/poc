import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FileText, Tag, Info, Save, ArrowLeft, Eye, Edit3 } from 'lucide-react';
import { motion } from 'motion/react';
import ReactMarkdown from 'react-markdown';

export default function EditWriteup() {
  const { id } = useParams();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [writeupId, setWriteupId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    tags: '',
    program: '',
    bounty: '',
    severity: 'Low'
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
      return;
    }

    const fetchWriteup = async () => {
      try {
        const res = await fetch(`/api/writeups/${id}?skipView=true`);
        if (res.status === 404) {
          navigate('/writeups');
          return;
        }
        if (!res.ok) throw new Error('Writeup not found');
        const data = await res.json();
        setWriteupId(data.id);
        
        // Security check: only author or admin can edit
        if (user && data.user_id !== user.id && user.role !== 'admin') {
          navigate(`/writeup/${id}`);
          return;
        }

        setFormData({
          title: data.title,
          content: data.content,
          tags: data.tags || '',
          program: data.program || '',
          bounty: data.bounty?.toString() || '',
          severity: data.severity || 'Low'
        });
      } catch (e) {
        console.error(e);
        navigate('/writeups');
      } finally {
        setLoading(false);
      }
    };

    if (user) fetchWriteup();
  }, [id, user, authLoading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Force at least one image
    const hasImage = /!\[.*?\]\((.*?)\)/.test(formData.content);
    if (!hasImage) {
      alert('You must include at least one image in your writeup content.');
      setSaving(false);
      return;
    }

    const titleWords = formData.title.trim().split(/\s+/).length;
    if (titleWords > 15) {
      alert('Writeup Title must not exceed 15 words.');
      return;
    }

    setSaving(true);
    try {
      if (!writeupId) throw new Error('Writeup ID not found');
      const res = await fetch(`/api/writeups/${writeupId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          bounty: formData.bounty ? parseFloat(formData.bounty) : null
        }),
      });
      const data = await res.json();
      if (res.ok) {
        navigate(`/writeup/${data.slug || id}`);
      } else {
        alert(data.error || 'Failed to update writeup');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-brand border-t-transparent"></div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="max-w-[1400px] mx-auto space-y-10 pb-20">
      <button 
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.2em] text-zinc-500 hover:text-white transition-colors"
      >
        <ArrowLeft size={14} />
        Back
      </button>

      <div className="space-y-4">
        <div className="inline-flex items-center gap-2 rounded-full bg-violet-500/10 px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-violet-400 border border-violet-500/20">
          Editor Mode
        </div>
        <h1 className="text-4xl font-black text-white tracking-tighter md:text-6xl uppercase">
          EDIT <span className="text-violet-500">WRITEUP</span>
        </h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="premium-card p-8 md:p-12 space-y-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500">Writeup Title</label>
              <div className="relative">
                <FileText className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
                <input
                  required
                  className="w-full rounded-2xl border border-white/5 bg-black/40 py-5 pr-5 pl-14 text-sm text-white focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/50 transition-all"
                  placeholder="How I found XSS on Google..."
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500">Target Program</label>
              <input
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/50 transition-all"
                placeholder="Google, Meta, Private Program..."
                value={formData.program}
                onChange={(e) => setFormData({ ...formData, program: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500">Bounty Amount (Optional)</label>
              <input
                type="number"
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/50 transition-all"
                placeholder="500"
                value={formData.bounty}
                onChange={(e) => setFormData({ ...formData, bounty: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500">Severity</label>
              <select
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/50 transition-all appearance-none"
                value={formData.severity}
                onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500">Tags (Comma separated)</label>
              <div className="relative">
                <Tag className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
                <input
                  className="w-full rounded-2xl border border-white/5 bg-black/40 py-5 pr-5 pl-14 text-sm text-white focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/50 transition-all"
                  placeholder="xss, bypass, waf, high-severity"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-black uppercase tracking-widest text-zinc-500">Content (Markdown Supported)</label>
                <div className="flex items-center gap-4">
                  <button 
                    type="button"
                    onClick={() => setShowPreview(!showPreview)}
                    className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-white transition-colors"
                  >
                    {showPreview ? (
                      <><Edit3 size={14} className="text-violet-400" /> EDIT</>
                    ) : (
                      <><Eye size={14} className="text-violet-400" /> PREVIEW</>
                    )}
                  </button>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-zinc-600">
                    <Info size={12} />
                    Use markdown for code blocks and formatting
                  </div>
                </div>
              </div>
              {showPreview ? (
                <div className="w-full min-h-[400px] rounded-2xl border border-white/5 bg-black/40 p-10 text-white prose max-w-none overflow-auto">
                  <ReactMarkdown>{formData.content || '*No content to preview*'}</ReactMarkdown>
                </div>
              ) : (
                <textarea
                  required
                  rows={15}
                  className="w-full rounded-2xl border border-white/5 bg-black/40 p-6 text-sm text-white focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/50 transition-all font-mono leading-relaxed"
                  placeholder="# Introduction\n\nDescribe your findings here..."
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                />
              )}
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <button
              type="submit"
              disabled={saving}
              className="btn-primary flex items-center gap-3 px-10 py-5 bg-violet-600 hover:bg-violet-500 shadow-violet-500/20"
            >
              <Save size={20} />
              {saving ? 'UPDATING...' : 'UPDATE WRITEUP'}
            </button>
          </div>
        </div>

        <div className="glass p-8 rounded-[2rem] border-white/5">
          <h3 className="text-sm font-black text-white uppercase tracking-widest mb-4">Markdown Tips</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-zinc-500 font-medium">
            <div className="space-y-2">
              <p><code className="text-violet-400"># Heading</code> - Large Title</p>
              <p><code className="text-violet-400">## Heading</code> - Section Title</p>
              <p><code className="text-violet-400">**bold**</code> - Bold Text</p>
            </div>
            <div className="space-y-2">
              <p><code className="text-violet-400">```js ... ```</code> - Code Block</p>
              <p><code className="text-violet-400">[Link](url)</code> - Hyperlink</p>
              <p><code className="text-violet-400">![Alt](url)</code> - Image</p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
