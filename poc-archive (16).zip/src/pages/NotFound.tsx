import { motion } from 'motion/react';
import { ArrowLeft, Home, Terminal, AlertTriangle, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
        className="relative w-full max-w-2xl overflow-hidden rounded-[2.5rem] bg-[#0a0a0a] border border-white/5 p-8 md:p-16 text-center"
      >
        {/* Decorative Background Elements */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand/5 to-transparent pointer-events-none" />
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-brand/5 blur-[80px]" />
        
        <div className="relative z-10 flex flex-col items-center">
          {/* Status Badge */}
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-brand mb-8 border border-brand/20">
            <AlertTriangle size={12} className="animate-pulse" />
            Error 404: Resource Unavailable
          </div>

          <h1 className="text-7xl md:text-9xl font-black tracking-tighter text-white leading-none mb-4">
            LOST <span className="text-brand">NODE.</span>
          </h1>
          
          <p className="text-zinc-400 text-lg md:text-xl font-medium max-w-md mx-auto leading-relaxed mb-10">
            The research data or technical asset you are looking for has been moved, deleted, or never existed in this sector.
          </p>

          {/* Technical Info Box */}
          <div className="w-full max-w-sm glass rounded-2xl p-4 mb-10 border-white/5 flex items-center gap-4 text-left">
            <div className="flex-shrink-0 h-10 w-10 rounded-xl bg-white/5 flex items-center justify-center text-zinc-500">
              <Terminal size={20} />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Diagnostic Info</p>
              <p className="text-xs font-mono text-zinc-300 truncate">HTTP_EXCEPTION: RESOURCE_NOT_FOUND</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
            <Link to="/" className="btn-primary w-full sm:w-auto flex items-center justify-center gap-2">
              <Home size={18} />
              BACK TO FEED
            </Link>
            
            <button 
              onClick={() => window.history.back()}
              className="btn-secondary w-full sm:w-auto flex items-center justify-center gap-2"
            >
              <ArrowLeft size={18} />
              GO BACK
            </button>
          </div>
        </div>

        {/* Bottom Decorative Line */}
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand/20 to-transparent" />
      </motion.div>

      {/* Search Suggestion */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-12 flex items-center gap-3 text-zinc-600 text-sm font-medium"
      >
        <Search size={16} />
        <span>Try searching for specific research in the dashboard</span>
      </motion.div>
    </div>
  );
}
