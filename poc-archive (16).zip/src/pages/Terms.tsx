import { motion } from 'motion/react';
import { Scale, CheckCircle, AlertTriangle, Info } from 'lucide-react';

export default function Terms() {
  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase">TERMS & <span className="text-brand">CONDITIONS</span></h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Please read these terms carefully before using our platform.</p>
        </div>

        <div className="glass p-10 rounded-[3rem] border-white/5 space-y-10">
          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Scale size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Acceptance of Terms</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              By accessing or using our platform, you agree to be bound by these Terms and Conditions and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <CheckCircle size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Ethical Research & Conduct</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              Users are expected to maintain the highest standards of ethical conduct. Our platform is strictly for authorized security research. Any attempt to use information found here for malicious purposes, unauthorized access, or illegal activities will result in immediate termination of access and potential legal action. You agree not to harass other researchers or exploit the platform's features.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Scale size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Content Submission & Permissions</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              By submitting Proof-of-Concepts (PoCs) or Writeups, you warrant that you have the necessary permissions from the affected organizations or bug bounty programs to disclose such information. You retain ownership of your content but grant the platform a non-exclusive license to display and distribute it. We reserve the right to remove any content that lacks proper authorization or violates our quality standards.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <AlertTriangle size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Account Security & Termination</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              You are responsible for maintaining the confidentiality of your account credentials. Any activity occurring under your account is your responsibility. We reserve the right to suspend or terminate accounts that violate these terms, engage in suspicious activity, or are deemed harmful to the community at our sole discretion.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Info size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Limitation of Liability</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              The platform and its administrators are not responsible for any misuse of the information provided. All research tools and PoCs are provided "as-is" without warranty. We are not liable for any damages, legal consequences, or system failures resulting from the application of techniques described on this site.
            </p>
          </section>

          <div className="pt-10 border-t border-white/5 text-center">
            <p className="text-zinc-600 text-sm">Last updated: March 12, 2026</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
