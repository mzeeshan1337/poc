import { motion } from 'motion/react';
import { BadgeCheck, ShieldCheck, FileText, Mail, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function BecomeVerified() {
  const steps = [
    {
      icon: <FileText className="text-blue-500" size={24} />,
      title: "Contribute Quality Content",
      description: "Submit at least 3 high-quality Proof-of-Concepts (PoCs) or technical writeups to the platform."
    },
    {
      icon: <ShieldCheck className="text-emerald-500" size={24} />,
      title: "Admin Review",
      description: "Our administrators will manually review your submissions for technical accuracy, clarity, and community value."
    },
    {
      icon: <BadgeCheck className="text-orange-500" size={24} />,
      title: "Get Verified",
      description: "Once approved, you'll receive the verified researcher badge on your profile and next to your name globally."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full bg-orange-500/10 px-4 py-1.5 text-xs font-black uppercase tracking-widest text-orange-500">
            <BadgeCheck size={14} />
            Researcher Verification
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase">BECOME <span className="text-brand">VERIFIED</span></h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Join the elite circle of trusted security researchers on our platform.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {steps.map((step, i) => (
            <div key={i} className="glass p-8 rounded-[2rem] border-white/5 space-y-4 relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 text-white/5 transition-transform group-hover:scale-110">
                {step.icon}
              </div>
              <div className="h-12 w-12 rounded-2xl bg-white/5 flex items-center justify-center">
                {step.icon}
              </div>
              <h3 className="text-xl font-bold text-white">{step.title}</h3>
              <p className="text-zinc-400 text-sm leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        <div className="glass p-10 rounded-[3rem] border-white/5 space-y-8">
          <div className="space-y-4">
            <h2 className="text-3xl font-black text-white tracking-tight uppercase">THE PROCESS</h2>
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 h-8 w-8 rounded-full bg-brand/20 flex items-center justify-center text-brand font-bold text-sm">1</div>
                <div>
                  <h4 className="font-bold text-white mb-1">Submit 3+ Contributions</h4>
                  <p className="text-zinc-500 text-sm">We look for technical depth, unique findings, and clear explanations in your PoCs and writeups.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 h-8 w-8 rounded-full bg-brand/20 flex items-center justify-center text-brand font-bold text-sm">2</div>
                <div>
                  <h4 className="font-bold text-white mb-1">Content Quality Review</h4>
                  <p className="text-zinc-500 text-sm">Our team evaluates if your content provides significant value to the security community.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 h-8 w-8 rounded-full bg-brand/20 flex items-center justify-center text-brand font-bold text-sm">3</div>
                <div>
                  <h4 className="font-bold text-white mb-1">Contact Support</h4>
                  <p className="text-zinc-500 text-sm">After meeting the criteria, send an email to our support team with your profile link.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-white/5">
            <div className="rounded-2xl bg-brand/5 border border-brand/20 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-brand flex items-center justify-center text-white">
                  <Mail size={24} />
                </div>
                <div>
                  <div className="text-xs font-bold text-brand uppercase tracking-widest mb-1">Ready to apply?</div>
                  <div className="text-xl font-bold text-white">contact@zeeshan.id</div>
                </div>
              </div>
              <a 
                href="mailto:contact@zeeshan.id?subject=Verification Request"
                className="btn-primary flex items-center gap-2 px-8 py-4"
              >
                SEND REQUEST <ArrowRight size={18} />
              </a>
            </div>
          </div>
        </div>

        <div className="text-center">
          <p className="text-zinc-600 text-sm">
            Verification is at the sole discretion of the platform administrators. 
            <br />
            Abuse of the verified status will lead to immediate revocation.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
