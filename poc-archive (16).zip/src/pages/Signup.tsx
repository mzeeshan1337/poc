import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Shield, Lock, Mail, User, AlertCircle } from 'lucide-react';

export default function Signup() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { user, login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!acceptTerms) {
      return setError('You must accept the Terms and Conditions');
    }
    setError('');
    setLoading(true);

    try {
      const avatar_url = `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${username}`;
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password, avatar_url }),
      });

      const data = await res.json();
      if (res.ok) {
        login(data);
        navigate('/');
      } else {
        setError(data.error || 'Signup failed');
      }
    } catch (e) {
      setError('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-160px)] items-center justify-center px-4">
      <div className="w-full max-w-md space-y-8 rounded-3xl border border-white/5 bg-[#15171e] p-8 shadow-2xl">
        <div className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-orange-500/20 text-orange-500">
            <Shield size={28} />
          </div>
          <h2 className="mt-6 text-3xl font-black tracking-tight text-white">Join the Archive</h2>
          <p className="mt-2 text-sm text-zinc-500">Create your researcher account</p>
        </div>

        {error && (
          <div className="flex items-center gap-2 rounded-lg bg-red-500/10 p-4 text-sm text-red-500 border border-red-500/20">
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="relative">
              <User className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500" size={18} />
              <input
                type="text"
                name="display-username"
                required
                className="w-full rounded-xl border border-white/5 bg-black/20 py-3 pr-4 pl-12 text-white focus:border-orange-500/50 focus:outline-none focus:ring-1 focus:ring-orange-500/50"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div className="relative">
              <Mail className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500" size={18} />
              <input
                type="email"
                name="email"
                autoComplete="username"
                required
                className="w-full rounded-xl border border-white/5 bg-black/20 py-3 pr-4 pl-12 text-white focus:border-orange-500/50 focus:outline-none focus:ring-1 focus:ring-orange-500/50"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="relative">
              <Lock className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500" size={18} />
              <input
                type="password"
                name="password"
                autoComplete="new-password"
                required
                className="w-full rounded-xl border border-white/5 bg-black/20 py-3 pr-4 pl-12 text-white focus:border-orange-500/50 focus:outline-none focus:ring-1 focus:ring-orange-500/50"
                placeholder="Password (min 8 characters)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-start gap-3">
            <input
              type="checkbox"
              id="terms"
              required
              className="mt-1 h-4 w-4 rounded border-white/10 bg-black/20 text-orange-500 focus:ring-orange-500/50"
              checked={acceptTerms}
              onChange={(e) => setAcceptTerms(e.target.checked)}
            />
            <label htmlFor="terms" className="text-sm text-zinc-400">
              I accept the{' '}
              <Link to="/terms" className="text-orange-500 hover:underline">
                Terms and Conditions
              </Link>{' '}
              and{' '}
              <Link to="/privacy" className="text-orange-500 hover:underline">
                Privacy Policy
              </Link>
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-orange-500 py-3 font-bold text-white transition-all hover:bg-orange-600 disabled:opacity-50"
          >
            {loading ? 'Creating Account...' : 'Sign Up'}
          </button>
        </form>

        <p className="text-center text-sm text-zinc-500">
          Already have an account?{' '}
          <Link to="/login" className="font-bold text-orange-500 hover:underline">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}
