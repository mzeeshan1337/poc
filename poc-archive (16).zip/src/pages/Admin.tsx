import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Shield, Users, FileVideo, FileText, Ban, CheckCircle, Search, Trash2, ExternalLink, Layout, BadgeCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { Link, useNavigate } from 'react-router-dom';
import VerifiedBadge from '../components/VerifiedBadge';

export default function Admin() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [pocs, setPocs] = useState<any[]>([]);
  const [writeups, setWriteups] = useState<any[]>([]);
  const [pendingPocs, setPendingPocs] = useState<any[]>([]);
  const [pendingWriteups, setPendingWriteups] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'pocs' | 'writeups' | 'ads' | 'programs' | 'approvals'>('stats');
  const [searchTerm, setSearchTerm] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<{ id?: number, handle?: string, type: 'poc' | 'writeup' | 'program' } | null>(null);
  const [isVdp, setIsVdp] = useState(false);
  const [adsScript, setAdsScript] = useState('');
  const [adsTxt, setAdsTxt] = useState('');
  const [announcement, setAnnouncement] = useState('');
  const [loginEnabled, setLoginEnabled] = useState(true);
  const [signupEnabled, setSignupEnabled] = useState(true);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [savingAds, setSavingAds] = useState(false);
  const [isEditingAds, setIsEditingAds] = useState(false);
  
  // New Program State
  const [newProgram, setNewProgram] = useState({
    name: '',
    platform: 'HackerOne',
    link: '',
    profile_picture: '',
    bounty_min: 0,
    bounty_max: 0,
    scope_tags: '',
    self_hosted: false
  });
  const [addingProgram, setAddingProgram] = useState(false);

  const fetchData = async () => {
    try {
      const [statsRes, usersRes, pocsRes, writeupsRes, pendingPocsRes, pendingWriteupsRes] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/users'),
        fetch('/api/pocs'),
        fetch('/api/writeups'),
        fetch('/api/admin/pending-pocs'),
        fetch('/api/admin/pending-writeups')
      ]);
      setStats(await statsRes.json());
      setUsers(await usersRes.json());
      
      const pocsData = await pocsRes.json();
      setPocs(pocsData.items || []);
      
      const writeupsData = await writeupsRes.json();
      setWriteups(writeupsData.items || []);

      setPendingPocs(await pendingPocsRes.json());
      setPendingWriteups(await pendingWriteupsRes.json());
      
      const programsRes = await fetch('/api/programs?limit=1000');
      const programsData = await programsRes.json();
      setPrograms(programsData.items || []);
      
      const adsRes = await fetch('/api/admin/ads');
      const adsData = await adsRes.json();
      setAdsScript(adsData.script || '');
      setAdsTxt(adsData.adsTxt || '');
      setAnnouncement(adsData.announcement || '');
      setLoginEnabled(adsData.loginEnabled ?? true);
      setSignupEnabled(adsData.signupEnabled ?? true);
      setMaintenanceMode(adsData.maintenanceMode ?? false);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!authLoading && (!user || user.role !== 'admin')) {
      navigate('/');
      return;
    }
    if (user?.role === 'admin') fetchData();
  }, [user, authLoading, navigate]);

  const handleStatusChange = async (userId: number, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'banned' : 'active';
    const res = await fetch(`/api/admin/users/${userId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus }),
    });
    if (res.ok) fetchData();
  };

  const handleVerifyChange = async (userId: number, currentVerified: boolean) => {
    const res = await fetch(`/api/admin/users/${userId}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_verified: !currentVerified }),
    });
    if (res.ok) fetchData();
  };

  const handleApproval = async (id: number, type: 'poc' | 'writeup', status: 'approved' | 'rejected') => {
    const endpoint = type === 'poc' ? `/api/admin/pocs/${id}/status` : `/api/admin/writeups/${id}/status`;
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (res.ok) fetchData();
  };

  const handleDeletePoc = async (id: number) => {
    try {
      const res = await fetch(`/api/admin/pocs/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setConfirmDelete(null);
        fetchData();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to delete PoC');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred while deleting');
    }
  };

  const handleDeleteWriteup = async (id: number) => {
    try {
      const res = await fetch(`/api/admin/writeups/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setConfirmDelete(null);
        fetchData();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to delete writeup');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred while deleting');
    }
  };

  const handleSaveAds = async () => {
    setSavingAds(true);
    try {
      const res = await fetch('/api/admin/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          script: adsScript, 
          adsTxt: adsTxt,
          announcement,
          loginEnabled,
          signupEnabled,
          maintenanceMode
        }),
      });
      if (res.ok) {
        alert('Settings updated successfully');
        setIsEditingAds(false);
      } else {
        alert('Failed to update ads script');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred while saving');
    } finally {
      setSavingAds(false);
    }
  };

  const handleAddProgram = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddingProgram(true);
    try {
      const token = localStorage.getItem('token');
      const programData = {
        ...newProgram,
        bounty_min: isVdp ? 0 : Number(newProgram.bounty_min),
        bounty_max: isVdp ? 0 : Number(newProgram.bounty_max),
        scope_tags: newProgram.scope_tags.split(',').map(t => t.trim()).filter(t => t)
      };
      const res = await fetch('/api/programs', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(programData),
      });
      if (res.ok) {
        alert('Program added successfully');
        setNewProgram({
          name: '',
          platform: 'HackerOne',
          link: '',
          profile_picture: '',
          bounty_min: 0,
          bounty_max: 0,
          scope_tags: '',
          self_hosted: false
        });
        setIsVdp(false);
        fetchData(); // Refresh list
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to add program');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred');
    } finally {
      setAddingProgram(false);
    }
  };

  const handleDeleteProgram = async (handle: string) => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/programs/${handle}`, { 
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        fetchData();
        setConfirmDelete(null);
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to delete program');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred');
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-brand border-t-transparent"></div>
      </div>
    );
  }

  if (user?.role !== 'admin') return null;

  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPocs = pocs.filter(p => p.title.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredWriteups = writeups.filter(w => w.title.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredPrograms = programs.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-black text-white">Admin Dashboard</h1>
          <p className="text-zinc-500">Platform moderation and statistics.</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 border-b border-white/5 pb-4">
        {[
          { id: 'stats', label: 'Statistics', icon: Shield },
          { id: 'users', label: 'Users', icon: Users },
          { id: 'approvals', label: 'Approvals', icon: CheckCircle, count: (stats?.pendingPocs || 0) + (stats?.pendingWriteups || 0) },
          { id: 'pocs', label: 'PoCs', icon: FileVideo },
          { id: 'writeups', label: 'Writeups', icon: FileText },
          { id: 'programs', label: 'Programs', icon: Shield },
          { id: 'ads', label: 'Settings', icon: Layout },
        ].map((tab) => (
          <button 
            key={tab.id}
            onClick={() => { setActiveTab(tab.id as any); setSearchTerm(''); }}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-bold transition-colors relative ${activeTab === tab.id ? 'text-orange-500' : 'text-zinc-500 hover:text-white'}`}
          >
            <tab.icon size={16} />
            {tab.label}
            {tab.count !== undefined && tab.count > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-orange-500 text-[10px] font-black text-white">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {activeTab === 'stats' && (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 lg:grid-cols-5">
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-500">
              <Users size={24} />
            </div>
            <div className="text-4xl font-black text-white">{stats?.users}</div>
            <div className="text-sm font-bold uppercase tracking-wider text-zinc-500">Total Researchers</div>
          </div>
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500/10 text-orange-500">
              <FileVideo size={24} />
            </div>
            <div className="text-4xl font-black text-white">{stats?.pocs}</div>
            <div className="text-sm font-bold uppercase tracking-wider text-zinc-500">PoCs Submitted</div>
          </div>
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-500">
              <FileText size={24} />
            </div>
            <div className="text-4xl font-black text-white">{stats?.writeups}</div>
            <div className="text-sm font-bold uppercase tracking-wider text-zinc-500">Writeups Published</div>
          </div>
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-yellow-500/10 text-yellow-500">
              <CheckCircle size={24} />
            </div>
            <div className="text-4xl font-black text-white">{stats?.pendingPocs}</div>
            <div className="text-sm font-bold uppercase tracking-wider text-zinc-500">Pending PoCs</div>
          </div>
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-yellow-500/10 text-yellow-500">
              <CheckCircle size={24} />
            </div>
            <div className="text-4xl font-black text-white">{stats?.pendingWriteups}</div>
            <div className="text-sm font-bold uppercase tracking-wider text-zinc-500">Pending Writeups</div>
          </div>
        </div>
      )}

      {activeTab === 'ads' && (
        <div className="space-y-6 max-w-4xl">
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500/10 text-orange-500">
                <Layout size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Platform Settings</h2>
                <p className="text-sm text-zinc-500">Manage global website configurations and ads.</p>
              </div>
              {!isEditingAds && (
                <button
                  onClick={() => setIsEditingAds(true)}
                  className="ml-auto flex items-center gap-2 rounded-xl bg-white/5 px-4 py-2 text-xs font-bold text-white hover:bg-white/10 transition-all"
                >
                  EDIT SETTINGS
                </button>
              )}
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className={`p-6 rounded-2xl border border-white/5 bg-black/20 ${!isEditingAds ? 'opacity-50' : ''}`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-white">Login Functionality</h3>
                    <button
                      disabled={!isEditingAds}
                      onClick={() => setLoginEnabled(!loginEnabled)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${loginEnabled ? 'bg-orange-500' : 'bg-zinc-700'}`}
                    >
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${loginEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                  </div>
                  <p className="text-xs text-zinc-500">Enable or disable user login across the platform. Admins can always login.</p>
                </div>

                <div className={`p-6 rounded-2xl border border-white/5 bg-black/20 ${!isEditingAds ? 'opacity-50' : ''}`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-white">Signup Functionality</h3>
                    <button
                      disabled={!isEditingAds}
                      onClick={() => setSignupEnabled(!signupEnabled)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${signupEnabled ? 'bg-orange-500' : 'bg-zinc-700'}`}
                    >
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${signupEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                  </div>
                  <p className="text-xs text-zinc-500">Enable or disable new user registrations.</p>
                </div>

                <div className={`p-6 rounded-2xl border border-white/5 bg-black/20 ${!isEditingAds ? 'opacity-50' : ''}`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-white">Maintenance Mode</h3>
                    <button
                      disabled={!isEditingAds}
                      onClick={() => setMaintenanceMode(!maintenanceMode)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${maintenanceMode ? 'bg-red-500' : 'bg-zinc-700'}`}
                    >
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${maintenanceMode ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                  </div>
                  <p className="text-xs text-zinc-500">Enable maintenance mode to block access for non-admin users.</p>
                </div>
              </div>

              <div className="h-px bg-white/5 my-6" />

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">
                  Site Announcement (Banner)
                </label>
                <textarea
                  className={`w-full h-32 rounded-2xl border border-white/5 bg-black/40 p-6 font-medium text-sm text-zinc-300 focus:border-orange-500/50 focus:outline-none transition-all ${!isEditingAds ? 'opacity-50 cursor-not-allowed' : ''}`}
                  placeholder="Enter announcement text to display on a site-wide banner..."
                  value={announcement}
                  onChange={(e) => setAnnouncement(e.target.value)}
                  readOnly={!isEditingAds}
                />
                <p className="mt-2 text-[10px] text-zinc-600">Leave empty to hide the announcement banner.</p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">
                  AdSense Script Tag
                </label>
                <textarea
                  className={`w-full h-48 rounded-2xl border border-white/5 bg-black/40 p-6 font-mono text-sm text-zinc-300 focus:border-orange-500/50 focus:outline-none transition-all ${!isEditingAds ? 'opacity-50 cursor-not-allowed' : ''}`}
                  placeholder="Paste your <script> tag here..."
                  value={adsScript}
                  onChange={(e) => setAdsScript(e.target.value)}
                  readOnly={!isEditingAds}
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">
                  ads.txt Content
                </label>
                <textarea
                  className={`w-full h-48 rounded-2xl border border-white/5 bg-black/40 p-6 font-mono text-sm text-zinc-300 focus:border-orange-500/50 focus:outline-none transition-all ${!isEditingAds ? 'opacity-50 cursor-not-allowed' : ''}`}
                  placeholder="google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0"
                  value={adsTxt}
                  onChange={(e) => setAdsTxt(e.target.value)}
                  readOnly={!isEditingAds}
                />
              </div>

              <div className="flex items-center justify-between pt-4">
                <div className="text-xs text-zinc-600 italic">
                  * Script is added to &lt;head&gt;. ads.txt is served at /ads.txt.
                </div>
                {isEditingAds && (
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => {
                        setIsEditingAds(false);
                        fetchData(); // Reset to saved values
                      }}
                      className="text-xs font-bold text-zinc-500 hover:text-white transition-colors"
                    >
                      CANCEL
                    </button>
                    <button
                      onClick={handleSaveAds}
                      disabled={savingAds}
                      className="btn-primary flex items-center gap-2"
                    >
                      {savingAds ? 'SAVING...' : 'SAVE CHANGES'}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'approvals' && (
        <div className="space-y-8">
          <div className="rounded-3xl border border-white/5 bg-[#15171e] overflow-hidden">
            <div className="p-6 border-b border-white/5 bg-white/5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <FileVideo size={20} className="text-orange-500" />
                Pending PoCs
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Researcher</th>
                    <th className="px-6 py-4">Submitted</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {pendingPocs.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-zinc-500 font-bold italic">No pending PoCs to review.</td>
                    </tr>
                  ) : (
                    pendingPocs.map((p) => (
                      <tr key={p.id} className="text-sm text-zinc-300 hover:bg-white/5">
                        <td className="px-6 py-4 font-bold text-white">
                          <Link to={`/poc/${p.id}`} className="hover:text-orange-500 transition-colors">{p.title}</Link>
                        </td>
                        <td className="px-6 py-4">{p.author_name}</td>
                        <td className="px-6 py-4 text-xs text-zinc-500">{format(new Date(p.created_at), 'MMM d, yyyy')}</td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button 
                              onClick={() => handleApproval(p.id, 'poc', 'approved')}
                              className="rounded-lg bg-emerald-500/10 px-3 py-1.5 text-[10px] font-black text-emerald-500 hover:bg-emerald-500 hover:text-white transition-all"
                            >
                              APPROVE
                            </button>
                            <button 
                              onClick={() => handleApproval(p.id, 'poc', 'rejected')}
                              className="rounded-lg bg-red-500/10 px-3 py-1.5 text-[10px] font-black text-red-500 hover:bg-red-500 hover:text-white transition-all"
                            >
                              REJECT
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-3xl border border-white/5 bg-[#15171e] overflow-hidden">
            <div className="p-6 border-b border-white/5 bg-white/5">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <FileText size={20} className="text-purple-500" />
                Pending Writeups
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Researcher</th>
                    <th className="px-6 py-4">Submitted</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {pendingWriteups.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-zinc-500 font-bold italic">No pending writeups to review.</td>
                    </tr>
                  ) : (
                    pendingWriteups.map((w) => (
                      <tr key={w.id} className="text-sm text-zinc-300 hover:bg-white/5">
                        <td className="px-6 py-4 font-bold text-white">
                          <Link to={`/writeup/${w.id}`} className="hover:text-purple-500 transition-colors">{w.title}</Link>
                        </td>
                        <td className="px-6 py-4">{w.author_name}</td>
                        <td className="px-6 py-4 text-xs text-zinc-500">{format(new Date(w.created_at), 'MMM d, yyyy')}</td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button 
                              onClick={() => handleApproval(w.id, 'writeup', 'approved')}
                              className="rounded-lg bg-emerald-500/10 px-3 py-1.5 text-[10px] font-black text-emerald-500 hover:bg-emerald-500 hover:text-white transition-all"
                            >
                              APPROVE
                            </button>
                            <button 
                              onClick={() => handleApproval(w.id, 'writeup', 'rejected')}
                              className="rounded-lg bg-red-500/10 px-3 py-1.5 text-[10px] font-black text-red-500 hover:bg-red-500 hover:text-white transition-all"
                            >
                              REJECT
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
      {activeTab === 'programs' && (
        <div className="space-y-6 max-w-4xl">
          <div className="rounded-3xl border border-white/5 bg-[#15171e] p-8">
            <h2 className="text-xl font-bold text-white mb-6">Add New Bug Bounty Program</h2>
            <form onSubmit={handleAddProgram} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Program Name</label>
                  <input
                    type="text"
                    required
                    className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none"
                    value={newProgram.name}
                    onChange={(e) => setNewProgram({ ...newProgram, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Platform</label>
                  <select
                    className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none"
                    value={newProgram.platform}
                    onChange={(e) => setNewProgram({ ...newProgram, platform: e.target.value })}
                  >
                    <option value="HackerOne">HackerOne</option>
                    <option value="Bugcrowd">Bugcrowd</option>
                    <option value="Intigriti">Intigriti</option>
                    <option value="YesWeHack">YesWeHack</option>
                    <option value="Immunefi">Immunefi</option>
                    <option value="Bugbase">Bugbase</option>
                    <option value="PatchDay">PatchDay</option>
                    <option value="IssueHunt">IssueHunt</option>
                    <option value="Cantina">Cantina</option>
                    <option value="Compass Security">Compass Security</option>
                    <option value="HackenProof">HackenProof</option>
                    <option value="Code4rena">Code4rena</option>
                    <option value="GObugfree">GObugfree</option>
                    <option value="BugRap">BugRap</option>
                    <option value="Remedy">Remedy</option>
                    <option value="Standoff365">Standoff365</option>
                    <option value="Self-Hosted">Self-Hosted</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Program Link</label>
                <input
                  type="url"
                  required
                  className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none"
                  value={newProgram.link}
                  onChange={(e) => setNewProgram({ ...newProgram, link: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Profile Picture URL</label>
                <input
                  type="url"
                  className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none"
                  value={newProgram.profile_picture}
                  onChange={(e) => setNewProgram({ ...newProgram, profile_picture: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Min Bounty ($)</label>
                  <input
                    type="number"
                    disabled={isVdp}
                    className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none disabled:opacity-50"
                    value={newProgram.bounty_min}
                    onChange={(e) => setNewProgram({ ...newProgram, bounty_min: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Max Bounty ($)</label>
                  <input
                    type="number"
                    disabled={isVdp}
                    className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none disabled:opacity-50"
                    value={newProgram.bounty_max}
                    onChange={(e) => setNewProgram({ ...newProgram, bounty_max: Number(e.target.value) })}
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-6">
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-black/20 border border-white/5 flex-1">
                  <input
                    type="checkbox"
                    id="is_vdp"
                    className="h-5 w-5 rounded border-white/10 bg-black/40 text-brand focus:ring-brand/50"
                    checked={isVdp}
                    onChange={(e) => setIsVdp(e.target.checked)}
                  />
                  <label htmlFor="is_vdp" className="text-sm font-bold text-white cursor-pointer">
                    VDP Only (No Bounty)
                  </label>
                </div>
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-black/20 border border-white/5 flex-1">
                  <input
                    type="checkbox"
                    id="self_hosted"
                    className="h-5 w-5 rounded border-white/10 bg-black/40 text-orange-500 focus:ring-orange-500/50"
                    checked={newProgram.self_hosted}
                    onChange={(e) => setNewProgram({ ...newProgram, self_hosted: e.target.checked })}
                  />
                  <label htmlFor="self_hosted" className="text-sm font-bold text-white cursor-pointer">
                    Self-Hosted Program
                  </label>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-zinc-500 mb-2">Scope Tags (comma separated)</label>
                <input
                  type="text"
                  placeholder="Web, Mobile, API, IoT..."
                  className="w-full rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-sm text-white focus:border-brand/50 focus:outline-none"
                  value={newProgram.scope_tags}
                  onChange={(e) => setNewProgram({ ...newProgram, scope_tags: e.target.value })}
                />
              </div>
              <button
                type="submit"
                disabled={addingProgram}
                className="btn-primary w-full"
              >
                {addingProgram ? 'ADDING...' : 'ADD PROGRAM'}
              </button>
            </form>
          </div>

          <div className="rounded-3xl border border-white/5 bg-[#15171e] overflow-hidden">
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">Existing Programs</h2>
              <div className="relative">
                <Search className="absolute top-1/2 left-3 -translate-y-1/2 text-zinc-500" size={14} />
                <input 
                  type="text"
                  placeholder="Search programs..."
                  className="rounded-xl border border-white/5 bg-black/40 py-2 pr-4 pl-9 text-xs text-white focus:outline-none"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                    <th className="px-6 py-4">Program</th>
                    <th className="px-6 py-4">Platform</th>
                    <th className="px-6 py-4">Type</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredPrograms.map((p: any) => (
                    <tr key={p.handle} className="text-sm text-zinc-300 hover:bg-white/5">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <img 
                            src={p.profile_picture || `https://api.dicebear.com/7.x/identicon/svg?seed=${p.name}`} 
                            alt={p.name}
                            className="h-8 w-8 rounded-lg object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <span className="font-bold text-white">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-zinc-500">{p.platform}</td>
                      <td className="px-6 py-4">
                        <span className={`rounded-md px-2 py-0.5 text-[10px] font-black uppercase ${p.bounty_max > 0 ? 'bg-brand/10 text-brand' : 'bg-zinc-500/10 text-zinc-500'}`}>
                          {p.bounty_max > 0 ? 'Bug Bounty' : 'VDP'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        {confirmDelete?.handle === p.handle && confirmDelete?.type === 'program' ? (
                          <div className="inline-flex items-center gap-2">
                            <button 
                              onClick={() => handleDeleteProgram(p.handle)}
                              className="rounded-lg bg-red-500 px-3 py-1 text-[10px] font-black text-white hover:bg-red-600"
                            >
                              CONFIRM
                            </button>
                            <button 
                              onClick={() => setConfirmDelete(null)}
                              className="rounded-lg bg-white/5 px-3 py-1 text-[10px] font-black text-zinc-400 hover:text-white"
                            >
                              CANCEL
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDelete({ handle: p.handle, type: 'program' })}
                            className="rounded-lg p-2 text-red-500 hover:bg-red-500/10 transition-colors"
                            title="Delete Program"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {(activeTab === 'users' || activeTab === 'pocs' || activeTab === 'writeups') && (
        <div className="space-y-6">
          <div className="relative">
            <Search className="absolute top-1/2 left-4 -translate-y-1/2 text-zinc-500" size={18} />
            <input 
              type="text"
              placeholder={`Search ${activeTab}...`}
              className="w-full rounded-2xl border border-white/5 bg-[#15171e] py-3 pr-4 pl-12 text-white focus:outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="overflow-hidden rounded-3xl border border-white/5 bg-[#15171e]">
            {activeTab === 'users' && (
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase tracking-wider text-zinc-500">
                    <th className="px-6 py-4">User</th>
                    <th className="px-6 py-4">Email</th>
                    <th className="px-6 py-4">Role</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredUsers.map((u: any) => (
                    <tr key={u.id} className="text-sm text-zinc-300 hover:bg-white/5">
                      <td className="px-6 py-4 font-bold text-white">
                        <div className="flex items-center gap-2">
                          <Link to={`/profile/${u.username}`} className="hover:text-orange-500 transition-colors">
                            {u.username}
                          </Link>
                          {u.is_verified === 1 && <VerifiedBadge />}
                        </div>
                      </td>
                      <td className="px-6 py-4">{u.email}</td>
                      <td className="px-6 py-4">
                        <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${u.role === 'admin' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'}`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase ${u.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                          {u.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleVerifyChange(u.id, u.is_verified === 1)}
                            className={`rounded-lg p-2 transition-colors ${u.is_verified === 1 ? 'text-orange-500 hover:bg-orange-500/10' : 'text-zinc-500 hover:bg-white/10'}`}
                            title={u.is_verified === 1 ? 'Unverify User' : 'Verify User'}
                          >
                            <BadgeCheck size={18} />
                          </button>
                          {u.id !== user.id && (
                            <button 
                              onClick={() => handleStatusChange(u.id, u.status)}
                              className={`rounded-lg p-2 transition-colors ${u.status === 'active' ? 'text-red-500 hover:bg-red-500/10' : 'text-emerald-500 hover:bg-emerald-500/10'}`}
                              title={u.status === 'active' ? 'Ban User' : 'Unban User'}
                            >
                              {u.status === 'active' ? <Ban size={18} /> : <CheckCircle size={18} />}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {activeTab === 'pocs' && (
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase tracking-wider text-zinc-500">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Researcher</th>
                    <th className="px-6 py-4">Severity</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredPocs.map((p: any) => (
                    <tr key={p.id} className="text-sm text-zinc-300 hover:bg-white/5">
                      <td className="px-6 py-4 font-bold text-white">{p.title}</td>
                      <td className="px-6 py-4">{p.author_name}</td>
                      <td className="px-6 py-4">
                        <span className="rounded-md bg-white/5 px-2 py-0.5 text-[10px] font-bold uppercase text-zinc-400">
                          {p.severity}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right space-x-2">
                        <Link to={`/poc/${p.id}`} className="inline-block rounded-lg p-2 text-zinc-500 hover:bg-white/10 hover:text-white">
                          <ExternalLink size={18} />
                        </Link>
                        {confirmDelete?.id === p.id && confirmDelete?.type === 'poc' ? (
                          <div className="inline-flex items-center gap-2">
                            <button 
                              onClick={() => handleDeletePoc(p.id)}
                              className="rounded-lg bg-red-500 px-3 py-1 text-[10px] font-black text-white hover:bg-red-600"
                            >
                              CONFIRM
                            </button>
                            <button 
                              onClick={() => setConfirmDelete(null)}
                              className="rounded-lg bg-white/5 px-3 py-1 text-[10px] font-black text-zinc-400 hover:text-white"
                            >
                              CANCEL
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDelete({ id: p.id, type: 'poc' })}
                            className="rounded-lg p-2 text-red-500 hover:bg-red-500/10"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {activeTab === 'writeups' && (
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase tracking-wider text-zinc-500">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Researcher</th>
                    <th className="px-6 py-4">Program</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredWriteups.map((w: any) => (
                    <tr key={w.id} className="text-sm text-zinc-300 hover:bg-white/5">
                      <td className="px-6 py-4 font-bold text-white">{w.title}</td>
                      <td className="px-6 py-4">{w.author_name}</td>
                      <td className="px-6 py-4 text-zinc-500">{w.program || 'General'}</td>
                      <td className="px-6 py-4 text-right space-x-2">
                        <Link to={`/writeup/${w.id}`} className="inline-block rounded-lg p-2 text-zinc-500 hover:bg-white/10 hover:text-white">
                          <ExternalLink size={18} />
                        </Link>
                        {confirmDelete?.id === w.id && confirmDelete?.type === 'writeup' ? (
                          <div className="inline-flex items-center gap-2">
                            <button 
                              onClick={() => handleDeleteWriteup(w.id)}
                              className="rounded-lg bg-red-500 px-3 py-1 text-[10px] font-black text-white hover:bg-red-600"
                            >
                              CONFIRM
                            </button>
                            <button 
                              onClick={() => setConfirmDelete(null)}
                              className="rounded-lg bg-white/5 px-3 py-1 text-[10px] font-black text-zinc-400 hover:text-white"
                            >
                              CANCEL
                            </button>
                          </div>
                        ) : (
                          <button 
                            onClick={() => setConfirmDelete({ id: w.id, type: 'writeup' })}
                            className="rounded-lg p-2 text-red-500 hover:bg-red-500/10"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
