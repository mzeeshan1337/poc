import { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { User, Calendar, Shield, Award, ThumbsUp, FileText, Edit2, Save, X, Lock, TrendingUp, Video, Book } from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import RelativeTime from '../components/RelativeTime';
import VerifiedBadge from '../components/VerifiedBadge';

export default function Profile() {
  const { username } = useParams();
  const { user: currentUser, refreshUser } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [editData, setEditData] = useState({ bio: '', avatar_url: '' });
  const [passwordData, setPasswordData] = useState({ currentPassword: '', newPassword: '' });
  const [activeTab, setActiveTab] = useState<'pocs' | 'writeups'>('pocs');
  const securityRef = useRef<HTMLDivElement>(null);

  const fetchProfile = async () => {
    try {
      const res = await fetch(`/api/users/${username}`);
      if (!res.ok) throw new Error('User not found');
      const data = await res.json();
      setProfile(data);
      setEditData({ bio: data.bio || '', avatar_url: data.avatar_url || '' });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [username]);

  useEffect(() => {
    if (isChangingPassword && securityRef.current) {
      securityRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [isChangingPassword]);

  const handleUpdate = async () => {
    const res = await fetch('/api/auth/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editData),
    });
    if (res.ok) {
      setIsEditing(false);
      fetchProfile();
      refreshUser();
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/auth/password', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(passwordData),
    });
    if (res.ok) {
      setIsChangingPassword(false);
      setPasswordData({ currentPassword: '', newPassword: '' });
      alert('Password updated successfully');
    } else {
      const data = await res.json();
      alert(data.error || 'Failed to update password');
    }
  };

  if (loading) return <div className="animate-pulse space-y-8"><div className="h-64 rounded-3xl bg-white/5" /><div className="h-96 rounded-3xl bg-white/5" /></div>;
  if (!profile) return <div className="py-20 text-center text-zinc-500">User not found.</div>;

  const isOwnProfile = currentUser?.id === profile?.id;

  return (
    <div className="space-y-6 pb-12">
      {/* Profile Header */}
      <div className="relative overflow-hidden premium-card p-5 md:p-8">
        <div className="absolute top-0 right-0 -mr-32 -mt-32 h-96 w-96 rounded-full bg-brand/10 blur-[120px]" />
        
        <div className="relative flex flex-col items-center gap-6 md:flex-row md:items-start">
          <div className="relative">
            <div className="h-24 w-24 overflow-hidden rounded-[1.25rem] border-2 border-brand/20 bg-zinc-900 shadow-2xl md:h-32 md:w-32">
              <img 
                src={profile.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${profile.username}`} 
                className="h-full w-full object-cover"
                alt={profile.username}
              />
            </div>
            {profile.role === 'admin' && (
              <div className="absolute -top-3 -right-3 rounded-xl bg-red-500 px-4 py-1.5 text-[10px] font-black uppercase tracking-widest text-white shadow-[0_0_20px_rgba(239,68,68,0.3)]">
                ADMIN
              </div>
            )}
          </div>

          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
              <div>
                <div className="flex items-center gap-2 justify-center md:justify-start">
                  <h1 className="text-3xl font-black text-white tracking-tighter uppercase md:text-4xl">{profile.username}</h1>
                  {profile.is_verified === 1 && <VerifiedBadge size={24} />}
                </div>
                <div className="mt-2 flex flex-wrap justify-center gap-3 text-[10px] font-bold uppercase tracking-widest text-zinc-500 md:justify-start">
                  <span className="flex items-center gap-2">
                    <Calendar size={18} className="text-brand" />
                    JOINED {format(new Date(profile.created_at), 'MMM yyyy')}
                  </span>
                  <span className="flex items-center gap-2">
                    <TrendingUp size={18} className="text-emerald-500" />
                    RANK #{profile.rank}
                  </span>
                </div>
              </div>
              
              {isOwnProfile ? (
                <div className="flex gap-3">
                  <button 
                    onClick={() => {
                      setIsEditing(!isEditing);
                      setIsChangingPassword(false);
                    }}
                    className="flex items-center gap-3 rounded-2xl bg-white/5 border border-white/10 px-6 py-3 text-xs font-black uppercase tracking-widest text-white transition-all hover:bg-white/10 hover:border-brand/30"
                  >
                    {isEditing ? <X size={18} /> : <Edit2 size={18} />}
                    {isEditing ? 'CANCEL' : 'EDIT PROFILE'}
                  </button>
                  <button 
                    onClick={() => {
                      setIsChangingPassword(!isChangingPassword);
                      setIsEditing(false);
                    }}
                    className="flex items-center gap-3 rounded-2xl bg-white/5 border border-white/10 px-6 py-3 text-xs font-black uppercase tracking-widest text-white transition-all hover:bg-white/10 hover:border-brand/30"
                  >
                    <Lock size={18} />
                    SECURITY
                  </button>
                </div>
              ) : (
                <div className="flex gap-3">
                  {/* Message button removed */}
                </div>
              )}
            </div>

            {isEditing ? (
              <div className="mt-10 space-y-6 glass p-8 rounded-[2rem] border-white/5">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Bio</label>
                  <textarea
                    className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all resize-none"
                    rows={4}
                    placeholder="Tell us about your research background..."
                    value={editData.bio}
                    onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Avatar URL</label>
                  <input
                    className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                    placeholder="https://..."
                    value={editData.avatar_url}
                    onChange={(e) => setEditData({ ...editData, avatar_url: e.target.value })}
                  />
                </div>
                <button 
                  onClick={handleUpdate}
                  className="btn-primary flex items-center gap-3 px-8"
                >
                  <Save size={18} />
                  SAVE CHANGES
                </button>
              </div>
            ) : (
              <p className="mt-4 max-w-2xl text-zinc-400 leading-relaxed text-sm font-medium">
                {profile.bio || "This researcher hasn't added a bio yet."}
              </p>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="mt-6 grid grid-cols-2 gap-4 border-t border-white/5 pt-5 md:grid-cols-4">
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center gap-2 text-zinc-600 md:justify-start">
              <Video size={14} />
              <span className="text-[8px] font-black uppercase tracking-widest">PoCs</span>
            </div>
            <div className="mt-1 text-xl font-black text-white tracking-tighter">{profile.poc_count}</div>
          </div>
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center gap-2 text-zinc-600 md:justify-start">
              <Book size={14} />
              <span className="text-[8px] font-black uppercase tracking-widest">Writeups</span>
            </div>
            <div className="mt-1 text-xl font-black text-white tracking-tighter">{profile.writeup_count}</div>
          </div>
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center gap-2 text-zinc-600 md:justify-start">
              <ThumbsUp size={14} />
              <span className="text-[8px] font-black uppercase tracking-widest">Total Likes</span>
            </div>
            <div className="mt-1 text-xl font-black text-white tracking-tighter">{profile.total_likes}</div>
          </div>
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center gap-2 text-zinc-600 md:justify-start">
              <Award size={14} />
              <span className="text-[8px] font-black uppercase tracking-widest">Global Rank</span>
            </div>
            <div className="mt-1 text-xl font-black text-white tracking-tighter">#{profile.rank}</div>
          </div>
        </div>
      </div>

      {isChangingPassword && (
        <motion.div 
          ref={securityRef}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="premium-card p-5 md:p-8 border-brand/30 shadow-[0_0_50px_rgba(242,125,38,0.1)]"
        >
          <div className="flex items-center gap-4 mb-10">
            <div className="p-3 rounded-2xl bg-brand/10 border border-brand/20 text-brand">
              <Lock size={24} />
            </div>
            <h2 className="text-3xl font-black text-white tracking-tighter uppercase">CHANGE PASSWORD</h2>
          </div>
          <form onSubmit={handlePasswordChange} className="max-w-md space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Current Password</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">New Password</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                value={passwordData.newPassword}
                onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
              />
            </div>
            <button 
              type="submit"
              className="btn-primary w-full py-5"
            >
              UPDATE PASSWORD
            </button>
          </form>
        </motion.div>
      )}

      {/* Content Tabs */}
      <div className="space-y-4">
        <div className="flex gap-6 border-b border-white/5">
          <button 
            onClick={() => setActiveTab('pocs')}
            className={`flex items-center gap-2 pb-4 text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === 'pocs' ? 'text-brand' : 'text-zinc-600 hover:text-white'}`}
          >
            <Shield size={16} />
            PoCs ({profile.pocs?.length || 0})
            {activeTab === 'pocs' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-1 bg-brand rounded-t-full" />}
          </button>
          <button 
            onClick={() => setActiveTab('writeups')}
            className={`flex items-center gap-2 pb-4 text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === 'writeups' ? 'text-brand' : 'text-zinc-600 hover:text-white'}`}
          >
            <FileText size={16} />
            Writeups ({profile.writeups?.length || 0})
            {activeTab === 'writeups' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-1 bg-brand rounded-t-full" />}
          </button>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {activeTab === 'pocs' ? (
            profile.pocs?.length > 0 ? (
              profile.pocs.map((poc: any) => (
                <Link 
                  key={poc.id} 
                  to={`/poc/${poc.id}`}
                  className="group relative overflow-hidden premium-card p-4 transition-all hover:scale-[1.02]"
                >
                  <div className="mb-4 text-lg font-bold text-white group-hover:text-brand transition-colors tracking-tight leading-tight">{poc.title}</div>
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-zinc-600">
                    <span className="text-brand/80">{poc.vuln_type}</span>
                    <span><RelativeTime date={poc.created_at} /></span>
                  </div>
                </Link>
              ))
            ) : (
              <div className="col-span-full py-24 text-center glass rounded-[3rem] border-white/5">
                <Shield size={48} className="mx-auto mb-4 text-zinc-800" />
                <p className="text-zinc-600 font-black uppercase tracking-widest">No PoCs submitted yet.</p>
              </div>
            )
          ) : (
            profile.writeups?.length > 0 ? (
              profile.writeups.map((writeup: any) => (
                <Link 
                  key={writeup.id} 
                  to={`/writeup/${writeup.id}`}
                  className="group relative overflow-hidden premium-card p-4 transition-all hover:scale-[1.02]"
                >
                  <div className="mb-4 text-lg font-bold text-white group-hover:text-brand transition-colors tracking-tight leading-tight">{writeup.title}</div>
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-zinc-600">
                    <span className="text-brand/80">{writeup.program || 'General'}</span>
                    <span><RelativeTime date={writeup.created_at} /></span>
                  </div>
                </Link>
              ))
            ) : (
              <div className="col-span-full py-24 text-center glass rounded-[3rem] border-white/5">
                <Book size={48} className="mx-auto mb-4 text-zinc-800" />
                <p className="text-zinc-600 font-black uppercase tracking-widest">No writeups published yet.</p>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}
