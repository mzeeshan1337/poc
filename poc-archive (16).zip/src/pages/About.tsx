import { motion } from 'motion/react';
import { Shield, Target, Users, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function About() {
  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter">ABOUT <span className="text-brand">US</span></h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Empowering security researchers to share knowledge and secure the digital world.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="glass p-8 rounded-[2rem] border-white/5 space-y-4">
            <div className="h-12 w-12 rounded-2xl bg-brand/10 flex items-center justify-center text-brand">
              <Shield size={24} />
            </div>
            <h3 className="text-xl font-bold text-white">Our Mission</h3>
            <p className="text-zinc-400 leading-relaxed">
              We aim to provide a platform where ethical hackers and security researchers can showcase their findings, learn from each other, and build a safer internet through collaboration and transparency.
            </p>
          </div>

          <div className="glass p-8 rounded-[2rem] border-white/5 space-y-4">
            <div className="h-12 w-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
              <Target size={24} />
            </div>
            <h3 className="text-xl font-bold text-white">Our Vision</h3>
            <p className="text-zinc-400 leading-relaxed">
              To become the leading repository of security research and Proof-of-Concepts, bridging the gap between researchers and organizations while fostering a culture of responsible disclosure.
            </p>
          </div>
        </div>

        <div className="space-y-8">
          <h2 className="text-3xl font-black text-white tracking-tight">WHY CHOOSE US?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: <Users />, title: "Community Driven", desc: "Built by researchers, for researchers." },
              { icon: <Award />, title: "Quality Research", desc: "Vetted PoCs and detailed technical writeups." },
              { icon: <Shield />, title: "Secure Platform", desc: "Focus on privacy and secure data handling." }
            ].map((item, i) => (
              <div key={i} className="p-6 rounded-2xl bg-white/5 border border-white/5 space-y-3">
                <div className="text-brand">{item.icon}</div>
                <h4 className="font-bold text-white">{item.title}</h4>
                <p className="text-sm text-zinc-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="glass p-10 rounded-[3rem] border-white/5 text-center space-y-6">
          <h2 className="text-3xl font-black text-white tracking-tight">JOIN THE ELITE</h2>
          <p className="text-zinc-400 max-w-xl mx-auto">
            Whether you're a seasoned pro or just starting your bug bounty journey, our platform provides the tools and community you need to excel.
          </p>
          <div className="pt-4">
            <Link to="/signup" className="btn-primary inline-block px-10 py-4">GET STARTED NOW</Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
