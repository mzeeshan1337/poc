import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import ReactMarkdown from 'react-markdown';
import { ThumbsUp, Eye, Calendar, User, MessageSquare, Tag, ArrowLeft, DollarSign, FileText, Edit2, Share2, Check } from 'lucide-react';
import { formatBounty } from '../lib/utils';
import RelativeTime from '../components/RelativeTime';
import CommentSection from '../components/CommentSection';
import VerifiedBadge from '../components/VerifiedBadge';

export default function WriteupDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [writeup, setWriteup] = useState<any>(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [isShared, setIsShared] = useState(false);

  const isAuthor = user && writeup && (user.id === writeup.user_id || user.role === 'admin');

  const fetchData = async (skipView = false) => {
    try {
      const wRes = await fetch(`/api/writeups/${id}${skipView ? '?skipView=true' : ''}`);
      if (wRes.status === 404) {
        setWriteup(null);
        setLoading(false);
        return;
      }
      if (!wRes.ok) throw new Error('Failed to fetch writeup');
      const writeupData = await wRes.json();
      setWriteup(writeupData);
      
      const cRes = await fetch(`/api/comments/writeup/${writeupData.id}`);
      if (cRes.ok) {
        setComments(await cRes.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const handleLike = async () => {
    if (!user || !writeup) return;
    
    // Optimistic update
    const wasLiked = writeup.is_liked;
    setWriteup(prev => ({
      ...prev,
      is_liked: !wasLiked,
      likes_count: wasLiked ? prev.likes_count - 1 : prev.likes_count + 1
    }));

    try {
      const res = await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_id: writeup.id, target_type: 'writeup' }),
      });
      if (!res.ok) {
        // Rollback on error
        setWriteup(prev => ({
          ...prev,
          is_liked: wasLiked,
          likes_count: wasLiked ? prev.likes_count + 1 : prev.likes_count - 1
        }));
      }
    } catch (e) {
      console.error(e);
      // Rollback on error
      setWriteup(prev => ({
        ...prev,
        is_liked: wasLiked,
        likes_count: wasLiked ? prev.likes_count + 1 : prev.likes_count - 1
      }));
    }
  };

  const handleShare = () => {
    const shareUrl = `${window.location.origin}/writeup/${writeup.slug || writeup.id}`;
    navigator.clipboard.writeText(shareUrl);
    setIsShared(true);
    setTimeout(() => setIsShared(false), 2000);
  };

  const readingTime = writeup ? Math.ceil(writeup.content.split(/\s+/).length / 200) : 0;

  if (loading) return (
    <div className="animate-pulse max-w-3xl mx-auto space-y-12 py-20">
      <div className="h-12 w-3/4 rounded-2xl bg-white/5" />
      <div className="flex items-center gap-4">
        <div className="h-12 w-12 rounded-full bg-white/5" />
        <div className="space-y-2">
          <div className="h-4 w-32 rounded bg-white/5" />
          <div className="h-3 w-24 rounded bg-white/5" />
        </div>
      </div>
      <div className="h-[600px] rounded-3xl bg-white/5" />
    </div>
  );
  
  if (!writeup) return (
    <div className="flex flex-col items-center justify-center py-32 text-center glass rounded-[3rem] max-w-3xl mx-auto">
      <div className="mb-6 rounded-full bg-white/5 p-8 text-zinc-700">
        <FileText size={64} strokeWidth={1} />
      </div>
      <h3 className="text-2xl font-bold text-white">Writeup not found</h3>
      <p className="text-zinc-500 mt-2">The research paper you're looking for might have been moved or deleted.</p>
    </div>
  );

  return (
    <div className="mx-auto max-w-3xl pb-20 pt-10 px-4 sm:px-6">
      <div className="mb-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <Link to="/writeups" className="inline-flex items-center gap-2 text-sm font-medium text-zinc-500 hover:text-white transition-colors">
          <ArrowLeft size={16} />
          Back to list
        </Link>

        {isAuthor && (
          <Link 
            to={`/edit-writeup/${id}`}
            className="flex items-center gap-2 rounded-full bg-white/5 border border-white/10 px-4 py-2 text-xs font-medium text-zinc-300 transition-all hover:bg-white/10 w-full sm:w-auto justify-center"
          >
            <Edit2 size={14} />
            Edit
          </Link>
        )}
      </div>

      <article className="space-y-10">
        <header className="space-y-8">
          <h1 className="text-4xl font-black text-white md:text-5xl lg:text-6xl tracking-tight leading-[1.1]">{writeup.title}</h1>
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-y border-white/5 py-6 gap-6">
            <div className="flex items-center gap-4">
              <Link to={`/profile/${writeup.author_name}`} className="relative">
                <div className="h-12 w-12 overflow-hidden rounded-full bg-zinc-900 border border-white/10">
                  <img 
                    src={writeup.author_avatar || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${writeup.author_name}`} 
                    className="h-full w-full object-cover"
                    alt={writeup.author_name}
                  />
                </div>
              </Link>
              <div>
                <div className="flex items-center gap-2">
                  <Link to={`/profile/${writeup.author_name}`} className="font-bold text-white hover:text-brand transition-colors">{writeup.author_name}</Link>
                  {writeup.author_verified === 1 && <VerifiedBadge />}
                </div>
                <div className="flex items-center gap-2 text-sm text-zinc-500">
                  <span>{readingTime} min read</span>
                  <span>•</span>
                  <span><RelativeTime date={writeup.created_at} /></span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
              <button 
                onClick={handleLike} 
                className={`flex items-center gap-2 text-zinc-500 hover:text-white transition-colors ${!user && 'opacity-50 cursor-not-allowed'}`}
              >
                <ThumbsUp size={20} className={writeup.is_liked ? 'fill-brand text-brand' : ''} />
                <span className="text-sm font-medium">{writeup.likes_count}</span>
              </button>
              <button 
                onClick={handleShare}
                className="text-zinc-500 hover:text-white transition-colors"
                title="Share research"
              >
                {isShared ? <Check size={20} className="text-emerald-500" /> : <Share2 size={20} />}
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="rounded-full bg-brand/10 px-3 py-1 text-xs font-bold text-brand uppercase tracking-wider">
              {writeup.program || 'General'}
            </span>
            <span className="rounded-full bg-white/5 px-3 py-1 text-xs font-bold text-zinc-400 uppercase tracking-wider">
              {writeup.severity || 'Low'} Severity
            </span>
            {writeup.bounty && (
              <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-500">
                {formatBounty(writeup.bounty)}
              </span>
            )}
          </div>
        </header>

        <div className="prose prose-invert prose-lg max-w-none">
          <ReactMarkdown>{writeup.content}</ReactMarkdown>
        </div>

        <footer className="pt-12 border-t border-white/5 mt-16 space-y-10">
          <div className="flex flex-wrap gap-2">
            {(writeup.tags || '').split(',').filter(Boolean).map((tag: string) => (
              <span key={tag} className="rounded-full bg-white/5 px-4 py-1.5 text-sm font-medium text-zinc-400 hover:bg-white/10 transition-colors cursor-default">
                {tag.trim()}
              </span>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-white/[0.02] rounded-2xl p-6 border border-white/5 gap-6">
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 overflow-hidden rounded-full bg-zinc-900 border border-white/10">
                <img 
                  src={writeup.author_avatar || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${writeup.author_name}`} 
                  className="h-full w-full object-cover"
                  alt={writeup.author_name}
                />
              </div>
              <div>
                <div className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-1">Written by</div>
                <div className="flex items-center gap-2">
                  <div className="text-xl font-bold text-white">{writeup.author_name}</div>
                  {writeup.author_verified === 1 && <VerifiedBadge />}
                </div>
              </div>
            </div>
            <Link 
              to={`/profile/${writeup.author_name}`}
              className="rounded-full border border-white/10 px-6 py-2 text-sm font-bold text-white hover:bg-white/5 transition-all w-full sm:w-auto text-center"
            >
              View Profile
            </Link>
          </div>
        </footer>
      </article>

      {/* Discussion Section */}
      <div className="mt-20">
        <CommentSection 
          targetId={writeup.id} 
          targetType="writeup" 
          comments={comments} 
          user={user} 
          onCommentAdded={() => fetchData(true)} 
        />
      </div>
    </div>
  );
}
