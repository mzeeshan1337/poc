import { useState, useEffect } from 'react';
import { Search, Filter, Globe, Shield, Trophy, ExternalLink, Calendar, Tag, DollarSign, LayoutGrid, Zap, BadgeCheck } from 'lucide-react';
import { motion } from 'motion/react';

export default function Programs() {
  const [programs, setPrograms] = useState([]);
  const [stats, setStats] = useState({ total: 0, vdp: 0, bb: 0, selfHosted: 0, platformCount: 16, platforms: {} as Record<string, number> });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [platform, setPlatform] = useState('');
  const [type, setType] = useState('');
  const [selfHosted, setSelfHosted] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchPrograms = async () => {
    setLoading(true);
    const params = new URLSearchParams({
      search,
      platform,
      type,
      self_hosted: selfHosted,
      page: page.toString(),
      limit: '30'
    });
    try {
      const res = await fetch(`/api/programs?${params}`);
      const data = await res.json();
      if (data.items) setPrograms(data.items);
      if (data.stats) setStats(data.stats);
      if (data.pagination) setTotalPages(data.pagination.totalPages);
    } catch (e) {
      console.error('Failed to fetch programs', e);
    }
    setLoading(false);
  };

  useEffect(() => {
    const timer = setTimeout(fetchPrograms, 300);
    return () => clearTimeout(timer);
  }, [search, platform, type, selfHosted, page]);

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-12 pb-20">
      {/* Header Section */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-[#0a0a0a] border border-white/5 p-8 md:p-16">
        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-[10px] font-black uppercase tracking-[0.2em] text-brand mb-8 border border-brand/20">
            <Globe size={12} />
            GLOBAL DIRECTORY
          </div>
          <h1 className="text-4xl font-black tracking-tighter text-white sm:text-5xl md:text-7xl leading-[1]">
            Bug Bounty <span className="text-brand">Programs.</span>
          </h1>
          <p className="mt-6 text-lg text-zinc-400 leading-relaxed max-w-2xl">
            Explore and filter through hundreds of active vulnerability disclosure and bug bounty programs across all major platforms.
          </p>
          
          <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="glass p-5 md:p-6 rounded-3xl border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all"
            >
              <div className="text-zinc-500 text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                <LayoutGrid size={12} className="text-brand" />
                Total Programs
              </div>
              <div className="text-2xl md:text-3xl font-black text-white">{stats.total.toLocaleString()}</div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass p-5 md:p-6 rounded-3xl border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all"
            >
              <div className="text-zinc-500 text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                <Trophy size={12} className="text-brand" />
                Bug Bounty
              </div>
              <div className="text-2xl md:text-3xl font-black text-brand">{stats.bb.toLocaleString()}</div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="glass p-5 md:p-6 rounded-3xl border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all"
            >
              <div className="text-zinc-500 text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                <Shield size={12} className="text-zinc-400" />
                VDP
              </div>
              <div className="text-2xl md:text-3xl font-black text-zinc-300">{stats.vdp.toLocaleString()}</div>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="glass p-5 md:p-6 rounded-3xl border-white/5 bg-white/[0.02] hover:bg-white/[0.04] transition-all"
            >
              <div className="text-zinc-500 text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                <Zap size={12} className="text-orange-500" />
                Self Hosted
              </div>
              <div className="text-2xl md:text-3xl font-black text-orange-500">{stats.selfHosted.toLocaleString()}</div>
            </motion.div>
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            {Object.entries(stats.platforms || {}).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, count]) => (
              <div key={name} className="flex items-center gap-2 rounded-full bg-white/5 border border-white/5 px-4 py-2 text-[10px] font-bold text-zinc-400">
                <span className="text-white">{name}</span>
                <span className="text-brand">{count}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-brand/5 to-transparent pointer-events-none" />
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between glass p-6 rounded-3xl border-white/5">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
          <input
            type="text"
            placeholder="Search programs by name or scope tags..."
            className="w-full rounded-2xl border border-white/5 bg-black/40 py-4 pr-5 pl-14 text-sm text-white focus:border-brand/50 focus:outline-none transition-all"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          />
        </div>
        
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter size={16} className="text-zinc-500" />
            <select 
              className="rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-xs font-bold uppercase tracking-wider text-zinc-400 focus:outline-none focus:border-brand/50 cursor-pointer"
              value={platform === '' && selfHosted === 'true' ? 'Self-Hosted' : platform}
              onChange={(e) => { 
                if (e.target.value === 'Self-Hosted') {
                  setSelfHosted('true');
                  setPlatform('');
                } else {
                  setSelfHosted('');
                  setPlatform(e.target.value);
                }
                setPage(1); 
              }}
            >
              <option value="">All Platforms</option>
              <option value="Self-Hosted">Self-Hosted Only</option>
              <option value="HackerOne">HackerOne</option>
              <option value="BugCrowd">BugCrowd</option>
              <option value="Intigriti">Intigriti</option>
              <option value="YesWeHack">YesWeHack</option>
              <option value="Immunefi">Immunefi</option>
              <option value="Bugbase">Bugbase</option>
              <option value="PatchDay">PatchDay</option>
              <option value="IssueHunt">IssueHunt</option>
              <option value="Cantina">Cantina</option>
              <option value="Compass Security">Compass Security</option>
              <option value="HackenProof">HackenProof</option>
              <option value="Code4rena">Code4rena</option>
              <option value="GObugfree">GObugfree</option>
              <option value="BugRap">BugRap</option>
              <option value="Remedy">Remedy</option>
              <option value="Standoff365">Standoff365</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <Zap size={16} className="text-zinc-500" />
            <select 
              className="rounded-xl border border-white/5 bg-black/40 px-4 py-3 text-xs font-bold uppercase tracking-wider text-zinc-400 focus:outline-none focus:border-brand/50 cursor-pointer"
              value={type}
              onChange={(e) => { setType(e.target.value); setPage(1); }}
            >
              <option value="">All Rewards</option>
              <option value="bb">Bug Bounty</option>
              <option value="vdp">VDP</option>
            </select>
          </div>
        </div>
        </div>

      {/* Programs Grid */}
      {loading ? (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
          {[...Array(9)].map((_, i) => (
            <div key={i} className="h-64 animate-pulse rounded-3xl bg-white/[0.02] border border-white/5" />
          ))}
        </div>
      ) : programs.length > 0 ? (
        <>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {programs.map((program: any, idx: number) => (
              <motion.div
                key={program.handle + idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="group relative flex flex-col glass rounded-[2rem] border border-white/5 overflow-hidden hover:border-brand/30 transition-all hover:shadow-2xl hover:shadow-brand/5"
              >
                {/* Top Area */}
                <div className="relative h-28 bg-gradient-to-br from-zinc-900 to-black flex items-center justify-center overflow-hidden border-b border-white/5">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(255,99,33,0.08),transparent)] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <div className="relative z-10 h-16 w-16 overflow-hidden rounded-2xl border border-white/10 bg-zinc-900 shadow-2xl group-hover:scale-110 transition-transform duration-500">
                    <img 
                      src={program.profile_picture && program.profile_picture !== "" ? program.profile_picture : `https://api.dicebear.com/7.x/identicon/svg?seed=${program.name}`} 
                      alt={program.name}
                      className="h-full w-full object-cover"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/identicon/svg?seed=${program.name}`;
                      }}
                    />
                  </div>
                  {program.self_hosted && (
                    <div className="absolute top-4 right-4 rounded-full bg-orange-500/10 border border-orange-500/20 px-2.5 py-1 text-[8px] font-black text-orange-500 uppercase tracking-widest flex items-center gap-1">
                      <Zap size={10} fill="currentColor" />
                      Self Hosted
                    </div>
                  )}
                </div>

                <div className="flex flex-col flex-1 p-6">
                  <div className="mb-5 text-center">
                    <h3 className="text-lg font-black text-white group-hover:text-brand transition-colors line-clamp-1 mb-1">{program.name}</h3>
                    <div className="flex items-center justify-center gap-2 text-[9px] font-black text-zinc-500 uppercase tracking-[0.2em]">
                      <Shield size={10} className="text-brand" />
                      {program.platform}
                    </div>
                  </div>

                  <div className="space-y-4 mb-8">
                    <div className="rounded-2xl bg-white/[0.02] p-4 border border-white/5 text-center">
                      <div className="text-[9px] font-black text-zinc-600 uppercase tracking-widest mb-2">
                        Bounty Range
                      </div>
                      <div className="text-base font-black text-white">
                        {program.bounty_max > 0 ? (
                          <span className="text-brand">
                            ${program.bounty_min?.toLocaleString() || 0} - ${program.bounty_max.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-zinc-500 italic text-sm">VDP (Points Only)</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-1.5 justify-center">
                      {program.scope_tags?.slice(0, 3).map((tag: string, i: number) => (
                        <span key={i} className="rounded-lg bg-white/5 px-2.5 py-1 text-[9px] font-bold text-zinc-400 uppercase tracking-wider border border-white/5">
                          {tag}
                        </span>
                      ))}
                      {program.scope_tags?.length > 3 && (
                        <span className="rounded-lg bg-white/5 px-2.5 py-1 text-[9px] font-bold text-zinc-600 uppercase tracking-wider">
                          +{program.scope_tags.length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mt-auto pt-4 border-t border-white/5">
                    <a 
                      href={program.link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-2 rounded-xl bg-white/5 border border-white/10 py-3.5 text-[10px] font-black uppercase tracking-widest text-white hover:bg-brand hover:border-brand transition-all group-hover:shadow-lg group-hover:shadow-brand/20"
                    >
                      View Program
                      <ExternalLink size={12} />
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-12 flex items-center justify-center gap-2">
              <button
                onClick={() => handlePageChange(Math.max(1, page - 1))}
                disabled={page === 1}
                className="btn-secondary px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <div className="flex items-center gap-2 px-4">
                <span className="text-sm font-bold text-white">Page {page}</span>
                <span className="text-sm text-zinc-500">of {totalPages}</span>
              </div>
              <button
                onClick={() => handlePageChange(Math.min(totalPages, page + 1))}
                disabled={page === totalPages}
                className="btn-secondary px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          )}
        </>
      ) : (
        <div className="flex flex-col items-center justify-center py-32 text-center glass rounded-[3rem]">
          <div className="mb-6 rounded-full bg-white/5 p-8 text-zinc-700">
            <Globe size={64} strokeWidth={1} />
          </div>
          <h3 className="text-2xl font-bold text-white">No programs found</h3>
          <p className="text-zinc-500 mt-2 max-w-xs">Try adjusting your search parameters or filters to find what you're looking for.</p>
        </div>
      )}
    </div>
  );
}
