import { motion } from 'motion/react';
import { Shield, Lock, Eye, FileText } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="max-w-4xl mx-auto py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="text-center space-y-4">
          <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase">PRIVACY <span className="text-brand">POLICY</span></h1>
          <p className="text-zinc-500 text-xl max-w-2xl mx-auto">Your privacy is our priority. Learn how we handle your data.</p>
        </div>

        <div className="glass p-10 rounded-[3rem] border-white/5 space-y-10">
          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Shield size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Information Collection</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              We collect information you provide directly to us when you create an account, submit a PoC, or communicate with us. This may include your username, email address, and any technical data you share in your submissions.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Eye size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">How We Use Information</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              We use the information we collect to provide, maintain, and improve our services, to process your submissions, and to communicate with you about updates, security alerts, and support messages.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <Lock size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Data Security & Research Integrity</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              We implement industry-standard security measures to protect your research data and personal information. Given the sensitive nature of security research, we employ encryption for data at rest and in transit. We do not share your private submission details with third parties without your consent, except as required by law or to protect the safety of our community.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3 text-brand">
              <FileText size={24} />
              <h2 className="text-2xl font-black tracking-tight uppercase">Data Retention & Deletion</h2>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              We retain your information for as long as your account is active or as needed to provide you services. You may request the deletion of your account and associated personal data at any time. Please note that public contributions like PoCs and Writeups may be anonymized rather than deleted to preserve the educational value of the platform, unless they contain PII.
            </p>
          </section>

          <div className="pt-10 border-t border-white/5 text-center">
            <p className="text-zinc-600 text-sm">Last updated: March 12, 2026</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
