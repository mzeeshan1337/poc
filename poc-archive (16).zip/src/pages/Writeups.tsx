import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FileText, Eye, ThumbsUp, Calendar, User, Search, PlusCircle, Filter, DollarSign } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { cn, formatBounty } from '../lib/utils';
import RelativeTime from '../components/RelativeTime';
import VerifiedBadge from '../components/VerifiedBadge';

export default function Writeups() {
  const [writeups, setWriteups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [program, setProgram] = useState('');
  const [minBounty, setMinBounty] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { user } = useAuth();

  const extractFirstImage = (content: string) => {
    const match = content.match(/!\[.*?\]\((.*?)\)/);
    return match ? match[1] : null;
  };

  const fetchWriteups = async () => {
    setLoading(true);
    const params = new URLSearchParams({
      search,
      program,
      minBounty,
      page: page.toString(),
      limit: '30'
    });
    const res = await fetch(`/api/writeups?${params}`);
    const data = await res.json();
    setWriteups(data.items);
    setTotalPages(data.pagination.totalPages);
    setLoading(false);
  };

  useEffect(() => {
    const timer = setTimeout(fetchWriteups, 300);
    return () => clearTimeout(timer);
  }, [search, program, minBounty, page]);

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredWriteups = writeups.filter((w: any) => 
    w.title.toLowerCase().includes(search.toLowerCase()) || 
    (w.tags || '').toLowerCase().includes(search.toLowerCase())
  );

  const severityColors: Record<string, string> = {
    Low: 'bg-green-500/10 text-green-500 border-green-500/20',
    Medium: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
    High: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    Critical: 'bg-red-500/10 text-red-500 border-red-500/20',
  };

  return (
    <div className="space-y-12 pb-20">
      <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-4xl font-black text-white md:text-6xl tracking-tighter">TECHNICAL <span className="text-brand">WRITEUPS</span></h1>
          <p className="mt-4 text-zinc-500 text-lg">Discover detailed technical analysis and security insights from professionals</p>
        </div>
        {user && (
          <Link to="/submit-writeup" className="btn-primary flex items-center gap-3">
            <PlusCircle size={20} />
            NEW WRITEUP
          </Link>
        )}
      </div>

      <div className="flex flex-col gap-6 md:flex-row glass p-6 rounded-3xl border-white/5">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={20} />
          <input
            type="text"
            placeholder="Search writeups by title, content or tags..."
            className="w-full rounded-2xl border border-white/5 bg-black/40 py-4 pr-5 pl-14 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="relative md:w-80">
          <Filter className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={18} />
          <input
            type="text"
            placeholder="Filter by Program..."
            className="w-full rounded-2xl border border-white/5 bg-black/40 py-4 pr-5 pl-14 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
            value={program}
            onChange={(e) => setProgram(e.target.value)}
          />
        </div>
        <div className="relative md:w-48">
          <DollarSign className="absolute top-1/2 left-5 -translate-y-1/2 text-zinc-600" size={18} />
          <input
            type="number"
            placeholder="Min Bounty..."
            className="w-full rounded-2xl border border-white/5 bg-black/40 py-4 pr-5 pl-14 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
            value={minBounty}
            onChange={(e) => setMinBounty(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-80 animate-pulse rounded-3xl bg-white/[0.02] border border-white/5" />
          ))}
        </div>
      ) : filteredWriteups.length > 0 ? (
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {writeups.map((writeup: any) => {
            const firstImage = extractFirstImage(writeup.content);
            return (
              <Link 
                key={writeup.id} 
                to={`/writeup/${writeup.slug || writeup.id}`}
                className="group relative flex flex-col overflow-hidden premium-card h-full transition-all hover:-translate-y-2"
              >
                <div className="relative aspect-video w-full overflow-hidden bg-zinc-900">
                  {firstImage ? (
                    <img 
                      src={firstImage} 
                      alt={writeup.title} 
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-zinc-900 text-zinc-800">
                      <FileText size={48} />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80" />
                  
                  <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                    <span className={cn("rounded-lg border px-2.5 py-1 text-xs font-black uppercase tracking-widest backdrop-blur-md", severityColors[writeup.severity] || severityColors.Low)}>
                      {writeup.severity || 'Low'}
                    </span>
                  </div>

                  {writeup.bounty && (
                    <div className="absolute bottom-4 right-4 flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-1.5 text-xs font-black text-white shadow-xl shadow-emerald-500/20">
                      <DollarSign size={14} />
                      {formatBounty(writeup.bounty)}
                    </div>
                  )}
                </div>

                <div className="flex flex-1 flex-col p-6">
                  <h3 className="mb-4 line-clamp-2 text-xl font-bold leading-tight text-white group-hover:text-brand transition-colors">
                    {writeup.title}
                  </h3>
                  
                  <div className="mt-auto space-y-4">
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1 text-xs font-black uppercase tracking-widest text-zinc-400">
                        {writeup.program || 'General'}
                      </span>
                      {(writeup.tags || '').split(',').slice(0, 2).map((tag: string) => (
                        <span key={tag} className="rounded-lg border border-brand/20 bg-brand/5 px-2.5 py-1 text-xs font-black uppercase tracking-widest text-brand">
                          {tag.trim()}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-zinc-900 flex items-center justify-center text-brand overflow-hidden border border-white/5">
                          <img 
                            src={writeup.author_avatar || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${writeup.author_name}`} 
                            className="h-full w-full object-cover"
                            alt={writeup.author_name}
                          />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-bold text-zinc-300">{writeup.author_name}</span>
                          {writeup.author_verified === 1 && <VerifiedBadge size={12} />}
                        </div>
                      </div>
                      <div className="flex items-center gap-4 text-sm font-bold text-zinc-500">
                        <div className="flex items-center gap-1.5">
                          <Eye size={16} className="text-zinc-600" />
                          <span>{writeup.views}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <ThumbsUp size={16} className="text-zinc-600" />
                          <span>{writeup.likes_count}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-white/5">
                      <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-zinc-600">
                        <Calendar size={14} />
                        <span><RelativeTime date={writeup.created_at} /></span>
                      </div>
                      <div className="text-xs font-black text-brand uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                        Read More →
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-32 text-center glass rounded-[3rem]">
          <div className="mb-6 rounded-full bg-white/5 p-8 text-zinc-700">
            <FileText size={64} strokeWidth={1} />
          </div>
          <h3 className="text-2xl font-bold text-white">No writeups found</h3>
          <p className="text-zinc-500 mt-2 max-w-xs">Try adjusting your search parameters to find the technical research you're looking for.</p>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-12 flex items-center justify-center gap-2">
          <button
            onClick={() => handlePageChange(Math.max(1, page - 1))}
            disabled={page === 1}
            className="btn-secondary px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          <div className="flex items-center gap-2 px-4">
            <span className="text-sm font-bold text-white">Page {page}</span>
            <span className="text-sm text-zinc-500">of {totalPages}</span>
          </div>
          <button
            onClick={() => handlePageChange(Math.min(totalPages, page + 1))}
            disabled={page === totalPages}
            className="btn-secondary px-4 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
