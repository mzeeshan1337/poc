import { useState, useEffect } from 'react';
import { Megaphone, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AnnouncementModal() {
  const [announcement, setAnnouncement] = useState('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch('/api/settings/public');
        const data = await res.json();
        if (data.announcement) {
          setAnnouncement(data.announcement);
          // Check if this specific announcement was dismissed
          const dismissed = localStorage.getItem('dismissed_announcement');
          if (dismissed !== data.announcement) {
            // Delay showing the modal slightly for better UX
            setTimeout(() => setIsVisible(true), 1000);
          }
        }
      } catch (e) {
        console.error('Failed to fetch announcement:', e);
      }
    };
    fetchSettings();
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    localStorage.setItem('dismissed_announcement', announcement);
  };

  if (!announcement) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleDismiss}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md"
          />

          {/* Modal Container */}
          <div className="fixed inset-0 z-[101] flex items-center justify-center p-4 pointer-events-none">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="pointer-events-auto relative w-full max-w-md overflow-hidden rounded-[2.5rem] border border-white/10 bg-[#15171e] p-8 shadow-[0_0_50px_-12px_rgba(249,115,22,0.3)]"
            >
              {/* Decorative background element */}
              <div className="pointer-events-none absolute -top-24 -right-24 h-48 w-48 rounded-full bg-brand/20 blur-3xl" />
              
              <button
                onClick={handleDismiss}
                className="absolute top-6 right-6 z-10 rounded-full p-2 text-zinc-500 hover:bg-white/10 hover:text-white transition-all active:scale-90"
                aria-label="Close modal"
              >
                <X size={20} />
              </button>

              <div className="relative flex flex-col items-center text-center">
                <motion.div 
                  initial={{ rotate: -10, scale: 0.9 }}
                  animate={{ rotate: 0, scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
                  className="mb-6 flex h-20 w-20 items-center justify-center rounded-[2rem] bg-brand/10 text-brand shadow-inner shadow-brand/20"
                >
                  <Megaphone size={36} strokeWidth={2.5} />
                </motion.div>

                <h2 className="mb-2 text-3xl font-black text-white uppercase tracking-tight italic">
                  Attention!
                </h2>
                
                <div className="h-1.5 w-16 bg-brand rounded-full mb-8 shadow-[0_0_15px_rgba(249,115,22,0.5)]" />

                <div className="mb-10 max-h-[40vh] overflow-y-auto px-2 custom-scrollbar">
                  <p className="text-lg text-zinc-300 leading-relaxed font-semibold">
                    {announcement}
                  </p>
                </div>

                <button
                  onClick={handleDismiss}
                  className="group relative w-full overflow-hidden rounded-2xl bg-brand py-4 text-base font-black uppercase tracking-[0.2em] text-white transition-all hover:bg-brand/90 active:scale-[0.98] shadow-xl shadow-brand/20"
                >
                  <span className="relative z-10">Got it, thanks!</span>
                  <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
                </button>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
