import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { User, Reply, MessageSquare, Send, ThumbsUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import RelativeTime from './RelativeTime';
import VerifiedBadge from './VerifiedBadge';

interface Comment {
  id: number;
  user_id: number;
  username: string;
  avatar_url: string;
  content: string;
  parent_id: number | null;
  created_at: string;
  likes_count: number;
  is_liked: boolean;
  is_verified: number;
}

interface CommentSectionProps {
  targetId: string | number;
  targetType: 'poc' | 'writeup';
  comments: Comment[];
  user: any;
  onCommentAdded: () => void;
}

export default function CommentSection({ targetId, targetType, comments: initialComments, user, onCommentAdded }: CommentSectionProps) {
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [comments, setComments] = useState<Comment[]>(initialComments);

  // Use useEffect to sync when initialComments changes
  useEffect(() => {
    setComments(initialComments);
  }, [initialComments]);

  const handleSubmit = async (e: React.FormEvent, parentId: number | null = null) => {
    e.preventDefault();
    const content = parentId ? replyContent : newComment;
    if (!content.trim() || submitting) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          target_id: targetId, 
          target_type: targetType, 
          content: content.trim(),
          parent_id: parentId
        }),
      });

      if (res.ok) {
        if (parentId) {
          setReplyContent('');
          setReplyingTo(null);
        } else {
          setNewComment('');
        }
        onCommentAdded();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async (commentId: number) => {
    if (!user) return;
    
    const wasLiked = comments.find(c => c.id === commentId)?.is_liked;
    
    // Optimistic update
    setComments(prev => prev.map(c => {
      if (c.id === commentId) {
        return {
          ...c,
          is_liked: !wasLiked,
          likes_count: wasLiked ? c.likes_count - 1 : c.likes_count + 1
        };
      }
      return c;
    }));

    try {
      const res = await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_id: commentId, target_type: 'comment' }),
      });
      if (!res.ok) {
        // Rollback on error
        setComments(initialComments);
      } else {
        // Still call onCommentAdded to sync with server state properly
        onCommentAdded();
      }
    } catch (e) {
      console.error(e);
      setComments(initialComments);
    }
  };

  const handleDelete = async (id: number) => {
    const res = await fetch(`/api/comments/${id}`, { method: 'DELETE' });
    if (res.ok) onCommentAdded();
  };

  const mainComments = comments.filter(c => !c.parent_id);
  const getReplies = (parentId: number) => comments.filter(c => c.parent_id === parentId);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <h2 className="text-xl font-bold text-white tracking-tight">
          {comments.length} Comments
        </h2>
      </div>
      
      {user ? (
        <form onSubmit={(e) => handleSubmit(e)} className="flex gap-4 mb-10">
          <div className="h-10 w-10 flex-shrink-0 overflow-hidden rounded-full bg-zinc-900 border border-white/5">
            <img 
              src={user.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${user.username}`} 
              className="h-full w-full object-cover"
              alt={user.username}
            />
          </div>
          <div className="flex-1 space-y-3">
            <textarea
              rows={1}
              placeholder="Add a comment..."
              className="w-full border-b border-white/10 bg-transparent py-1 text-sm text-white focus:border-white focus:outline-none transition-all resize-none overflow-hidden"
              value={newComment}
              onChange={(e) => {
                setNewComment(e.target.value);
                e.target.style.height = 'auto';
                e.target.style.height = e.target.scrollHeight + 'px';
              }}
            />
            <div className={`flex justify-end gap-3 transition-all ${newComment.trim() ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
              <button 
                type="button"
                onClick={() => setNewComment('')}
                className="px-4 py-2 text-sm font-bold text-white hover:bg-white/5 rounded-full transition-all"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                disabled={submitting || !newComment.trim()}
                className="bg-brand text-white px-4 py-2 text-sm font-bold rounded-full disabled:opacity-50 disabled:bg-zinc-800 transition-all"
              >
                Comment
              </button>
            </div>
          </div>
        </form>
      ) : (
        <div className="py-6 border-b border-white/5 text-center">
          <p className="text-zinc-500 text-sm">Please <Link to="/login" className="text-brand hover:underline">login</Link> to join the discussion.</p>
        </div>
      )}

      <div className="space-y-6">
        {mainComments.map((comment) => (
          <div key={comment.id} className="flex gap-4">
            <Link to={`/profile/${comment.username}`} className="h-10 w-10 flex-shrink-0 overflow-hidden rounded-full bg-zinc-900 border border-white/5">
              <img 
                src={comment.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${comment.username}`} 
                className="h-full w-full object-cover"
                alt={comment.username}
              />
            </Link>
            <div className="flex-1 space-y-1">
              <div className="flex items-center gap-2">
                <Link to={`/profile/${comment.username}`} className="text-xs font-bold text-white hover:text-zinc-300 transition-colors">
                  @{comment.username}
                </Link>
                {comment.is_verified === 1 && <VerifiedBadge size={10} />}
                <span className="text-[11px] text-zinc-500"><RelativeTime date={comment.created_at} /></span>
              </div>
              <p className="text-sm text-zinc-300 leading-normal">{comment.content}</p>
              
              <div className="flex items-center gap-4 pt-1">
                <button 
                  onClick={() => handleLike(comment.id)}
                  className={`flex items-center gap-1.5 transition-colors ${comment.is_liked ? 'text-brand' : 'text-zinc-500 hover:text-white'}`}
                >
                  <ThumbsUp size={14} className={comment.is_liked ? 'fill-brand' : ''} />
                  <span className="text-[11px]">{comment.likes_count}</span>
                </button>
                <button 
                  onClick={() => setReplyingTo(replyingTo === comment.id ? null : comment.id)}
                  className="text-[11px] font-bold text-zinc-500 hover:bg-white/5 px-3 py-1 rounded-full transition-colors"
                >
                  Reply
                </button>
                {(user?.id === comment.user_id || user?.role === 'admin') && (
                  <button 
                    onClick={() => handleDelete(comment.id)}
                    className="text-[11px] font-bold text-zinc-500 hover:text-red-500 transition-colors"
                  >
                    Delete
                  </button>
                )}
              </div>

              {/* Reply Form */}
              <AnimatePresence>
                {replyingTo === comment.id && (
                  <motion.form 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    onSubmit={(e) => handleSubmit(e, comment.id)}
                    className="overflow-hidden pt-4"
                  >
                    <div className="flex gap-3">
                      <div className="h-6 w-6 flex-shrink-0 overflow-hidden rounded-full bg-zinc-900 border border-white/5">
                        <img 
                          src={user?.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${user?.username}`} 
                          className="h-full w-full object-cover"
                          alt={user?.username}
                        />
                      </div>
                      <div className="flex-1 space-y-2">
                        <textarea
                          rows={1}
                          placeholder="Add a reply..."
                          className="w-full border-b border-white/10 bg-transparent py-1 text-sm text-white focus:border-white focus:outline-none transition-all resize-none overflow-hidden"
                          value={replyContent}
                          onChange={(e) => {
                            setReplyContent(e.target.value);
                            e.target.style.height = 'auto';
                            e.target.style.height = e.target.scrollHeight + 'px';
                          }}
                          autoFocus
                        />
                        <div className="flex justify-end gap-2">
                          <button 
                            type="button"
                            onClick={() => setReplyingTo(null)}
                            className="px-3 py-1.5 text-xs font-bold text-white hover:bg-white/5 rounded-full transition-all"
                          >
                            Cancel
                          </button>
                          <button 
                            type="submit" 
                            disabled={submitting || !replyContent.trim()}
                            className="bg-brand text-white px-3 py-1.5 text-xs font-bold rounded-full disabled:opacity-50 transition-all"
                          >
                            Reply
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>

              {/* Replies List */}
              <div className="space-y-4 pt-2">
                {getReplies(comment.id).map((reply) => (
                  <div key={reply.id} className="flex gap-3">
                    <Link to={`/profile/${reply.username}`} className="h-6 w-6 flex-shrink-0 overflow-hidden rounded-full bg-zinc-900 border border-white/5">
                      <img 
                        src={reply.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${reply.username}`} 
                        className="h-full w-full object-cover"
                        alt={reply.username}
                      />
                    </Link>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <Link to={`/profile/${reply.username}`} className="text-[11px] font-bold text-white hover:text-zinc-300 transition-colors">
                          @{reply.username}
                        </Link>
                        {reply.is_verified === 1 && <VerifiedBadge size={10} />}
                        <span className="text-[10px] text-zinc-500"><RelativeTime date={reply.created_at} /></span>
                      </div>
                      <p className="text-sm text-zinc-300 leading-normal">{reply.content}</p>
                      <div className="flex items-center gap-3 pt-1">
                        <button 
                          onClick={() => handleLike(reply.id)}
                          className={`flex items-center gap-1 transition-colors ${reply.is_liked ? 'text-brand' : 'text-zinc-500 hover:text-white'}`}
                        >
                          <ThumbsUp size={12} className={reply.is_liked ? 'fill-brand' : ''} />
                          <span className="text-[10px]">{reply.likes_count}</span>
                        </button>
                        {(user?.id === reply.user_id || user?.role === 'admin') && (
                          <button 
                            onClick={() => handleDelete(reply.id)}
                            className="text-[10px] font-bold text-zinc-500 hover:text-red-500 transition-colors"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}

        {mainComments.length === 0 && (
          <div className="text-center py-12 text-zinc-600">
            <MessageSquare size={40} className="mx-auto mb-3 opacity-20" />
            <p className="text-sm font-medium">No comments yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
