import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Shield, LogOut, User, PlusCircle, LayoutGrid, Trophy, FileText, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    setIsMenuOpen(false);
    navigate('/login');
  };

  return (
    <nav className="sticky top-0 z-50 glass border-b border-white/5">
      <div className="mx-auto flex h-20 max-w-[1600px] items-center justify-between px-4 sm:px-6 lg:px-12">
        <Link to="/" className="flex items-center gap-3 group" onClick={() => setIsMenuOpen(false)}>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand/10 text-brand transition-transform group-hover:scale-110">
            <Shield size={24} />
          </div>
          <span className="text-2xl font-bold tracking-tighter text-white">POC <span className="text-brand">ARCHIVE</span></span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden items-center gap-8 md:flex">
          <Link to="/" className="text-sm font-semibold tracking-wide uppercase text-zinc-400 transition-colors hover:text-white">Feed</Link>
          <Link to="/writeups" className="text-sm font-semibold tracking-wide uppercase text-zinc-400 transition-colors hover:text-white">Writeups</Link>
          <Link to="/programs" className="text-sm font-semibold tracking-wide uppercase text-zinc-400 transition-colors hover:text-white">Programs</Link>
          <Link to="/leaderboard" className="text-sm font-semibold tracking-wide uppercase text-zinc-400 transition-colors hover:text-white">Leaderboard</Link>
        </div>

        <div className="flex items-center gap-5">
          {user && (
            <Link to="/submit" className="hidden md:flex items-center gap-2 rounded-xl bg-brand px-5 py-2.5 text-sm font-bold text-white transition-all hover:brightness-110 hover:shadow-lg hover:shadow-brand/20 active:scale-95">
              <PlusCircle size={18} />
              SUBMIT
            </Link>
          )}
          
          {user && user.role === 'admin' && (
            <Link to="/admin" className="hidden sm:block text-[10px] font-black uppercase tracking-[0.2em] text-brand border border-brand/20 px-2 py-1 rounded hover:bg-brand/10">Admin</Link>
          )}
          
          {/* Mobile Menu Toggle */}
          <button 
            className="flex md:hidden text-zinc-400 hover:text-white transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>

          {user ? (
            <div className="hidden items-center gap-5 md:flex">
              <Link to={`/profile/${user.username}`} className="flex items-center gap-3 group">
                <div className="h-10 w-10 overflow-hidden rounded-full border-2 border-white/5 bg-zinc-900 transition-all group-hover:border-brand/50">
                  <img 
                    src={user.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${user.username}`} 
                    className="h-full w-full object-cover"
                    alt={user.username}
                  />
                </div>
                <span className="hidden text-sm font-bold text-zinc-300 group-hover:text-white sm:block">{user.username}</span>
              </Link>
              <button onClick={handleLogout} className="text-zinc-500 hover:text-red-500 transition-colors">
                <LogOut size={22} />
              </button>
            </div>
          ) : (
            <div className="hidden items-center gap-6 md:flex">
              <Link to="/login" className="text-sm font-bold text-zinc-400 hover:text-white transition-colors">LOGIN</Link>
              <Link to="/signup" className="rounded-xl bg-white/5 border border-white/10 px-6 py-2.5 text-sm font-bold text-white transition-all hover:bg-white/10 active:scale-95">SIGN UP</Link>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-white/5 bg-surface overflow-hidden"
          >
            <div className="flex flex-col p-6 gap-6">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-zinc-300 hover:text-white">Feed</Link>
              <Link to="/writeups" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-zinc-300 hover:text-white">Writeups</Link>
              <Link to="/programs" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-zinc-300 hover:text-white">Programs</Link>
              <Link to="/leaderboard" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-zinc-300 hover:text-white">Leaderboard</Link>
              
              {user ? (
                <>
                  <Link to="/submit" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-center gap-2 rounded-xl bg-brand py-4 text-lg font-bold text-white">
                    <PlusCircle size={20} />
                    SUBMIT POC
                  </Link>
                  <div className="h-px bg-white/5 my-2" />
                  <Link to={`/profile/${user.username}`} onClick={() => setIsMenuOpen(false)} className="flex items-center gap-4">
                    <div className="h-12 w-12 overflow-hidden rounded-full border-2 border-brand/50 bg-zinc-900">
                      <img 
                        src={user.avatar_url || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${user.username}`} 
                        className="h-full w-full object-cover"
                        alt={user.username}
                      />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-lg font-bold text-white">{user.username}</span>
                      <span className="text-sm text-zinc-500 uppercase tracking-widest">{user.role}</span>
                    </div>
                  </Link>
                  {user.role === 'admin' && (
                    <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-brand">Admin Dashboard</Link>
                  )}
                  <button 
                    onClick={handleLogout}
                    className="flex items-center gap-3 text-lg font-bold text-red-500 mt-2"
                  >
                    <LogOut size={20} />
                    Logout
                  </button>
                </>
              ) : (
                <div className="flex flex-col gap-4 mt-4">
                  <Link to="/login" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-center rounded-xl bg-white/5 border border-white/10 py-4 text-lg font-bold text-white">LOGIN</Link>
                  <Link to="/signup" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-center rounded-xl bg-brand py-4 text-lg font-bold text-white">SIGN UP</Link>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

