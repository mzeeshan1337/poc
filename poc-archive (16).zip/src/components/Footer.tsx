import { Link } from 'react-router-dom';
import { Shield, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-black/20 pt-16 pb-8">
      <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-4">
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand shadow-lg shadow-brand/20">
                <Shield className="text-white" size={24} />
              </div>
              <span className="text-xl font-black tracking-tighter text-white">POC<span className="text-brand">ARCHIVE</span></span>
            </Link>
            <p className="text-sm text-zinc-500 leading-relaxed max-w-xs">
              The premier archive for security research, Proof-of-Concepts, and technical writeups. Empowering the global security community.
            </p>
            <div className="flex gap-4">
              <a href="mailto:contact@zeeshan.id" className="h-10 w-10 rounded-xl bg-white/5 flex items-center justify-center text-zinc-500 hover:text-white hover:bg-white/10 transition-all">
                <Mail size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-white mb-6">Platform</h4>
            <ul className="space-y-4">
              <li><Link to="/writeups" className="text-sm text-zinc-500 hover:text-brand transition-colors">Technical Writeups</Link></li>
              <li><Link to="/" className="text-sm text-zinc-500 hover:text-brand transition-colors">PoC Archive</Link></li>
              <li><Link to="/leaderboard" className="text-sm text-zinc-500 hover:text-brand transition-colors">Leaderboard</Link></li>
              <li><Link to="/programs" className="text-sm text-zinc-500 hover:text-brand transition-colors">Bug Bounty Programs</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-white mb-6">Company</h4>
            <ul className="space-y-4">
              <li><Link to="/about" className="text-sm text-zinc-500 hover:text-brand transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="text-sm text-zinc-500 hover:text-brand transition-colors">Contact Us</Link></li>
              <li><Link to="/privacy" className="text-sm text-zinc-500 hover:text-brand transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="text-sm text-zinc-500 hover:text-brand transition-colors">Terms & Conditions</Link></li>
              <li><Link to="/cookies" className="text-sm text-zinc-500 hover:text-brand transition-colors">Cookie Policy</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-white mb-6">Support</h4>
            <ul className="space-y-4">
              <li><Link to="/disclaimer" className="text-sm text-zinc-500 hover:text-brand transition-colors">Disclaimer</Link></li>
              <li><Link to="/become-verified" className="text-sm text-zinc-500 hover:text-brand transition-colors">Become Verified</Link></li>
              <li><Link to="/contact" className="text-sm text-zinc-500 hover:text-brand transition-colors">Help Center</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-zinc-600 font-medium">
            © 2026 POCARCHIVE. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy" className="text-[10px] font-black uppercase tracking-widest text-zinc-600 hover:text-zinc-400 transition-colors">Privacy</Link>
            <Link to="/terms" className="text-[10px] font-black uppercase tracking-widest text-zinc-600 hover:text-zinc-400 transition-colors">Terms</Link>
            <Link to="/cookies" className="text-[10px] font-black uppercase tracking-widest text-zinc-600 hover:text-zinc-400 transition-colors">Cookies</Link>
            <Link to="/disclaimer" className="text-[10px] font-black uppercase tracking-widest text-zinc-600 hover:text-zinc-400 transition-colors">Disclaimer</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
