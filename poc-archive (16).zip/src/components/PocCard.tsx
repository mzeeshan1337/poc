import { Link } from 'react-router-dom';
import { Eye, ThumbsUp, Calendar, User, DollarSign } from 'lucide-react';
import { cn, getYouTubeThumbnail, formatBounty } from '../lib/utils';
import { motion } from 'motion/react';
import RelativeTime from './RelativeTime';
import VerifiedBadge from './VerifiedBadge';

interface PocCardProps {
  poc: {
    id: number;
    title: string;
    vuln_type: string;
    severity: string;
    author_name: string;
    author_avatar?: string;
    author_verified?: number;
    views: number;
    likes_count: number;
    created_at: string;
    youtube_url: string;
    bounty?: number;
    slug?: string;
  };
}

export default function PocCard({ poc }: PocCardProps) {
  const severityColors: Record<string, string> = {
    Low: 'bg-green-500/10 text-green-500 border-green-500/20',
    Medium: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
    High: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    Critical: 'bg-red-500/10 text-red-500 border-red-500/20',
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -8 }}
      transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
    >
      <Link to={`/poc/${poc.slug || poc.id}`} className="group relative flex flex-col overflow-hidden premium-card h-full">
        <div className="relative aspect-video w-full overflow-hidden">
          <img 
            src={getYouTubeThumbnail(poc.youtube_url)} 
            alt={poc.title} 
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80" />
          
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            <span className={cn("rounded-lg border px-2.5 py-1 text-xs font-black uppercase tracking-widest backdrop-blur-md", severityColors[poc.severity] || severityColors.Low)}>
              {poc.severity}
            </span>
            <span className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1 text-xs font-black uppercase tracking-widest text-white backdrop-blur-md">
              {poc.vuln_type}
            </span>
          </div>

          {poc.bounty && (
            <div className="absolute bottom-4 right-4 flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-1.5 text-xs font-black text-white shadow-xl shadow-emerald-500/20">
              <DollarSign size={14} />
              {formatBounty(poc.bounty)}
            </div>
          )}
        </div>

        <div className="flex flex-1 flex-col p-6">
          <h3 className="mb-4 line-clamp-2 text-xl font-bold leading-tight text-white group-hover:text-brand transition-colors">
            {poc.title}
          </h3>
          
          <div className="mt-auto space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Link to={`/profile/${poc.author_name}`} className="h-8 w-8 overflow-hidden rounded-full border border-white/5 bg-zinc-900 transition-all hover:border-brand/50">
                  <img 
                    src={poc.author_avatar || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${poc.author_name}`} 
                    className="h-full w-full object-cover"
                    alt={poc.author_name}
                  />
                </Link>
                <div className="flex items-center gap-1.5">
                  <Link to={`/profile/${poc.author_name}`} className="text-sm font-bold text-zinc-300 hover:text-white transition-colors">
                    {poc.author_name}
                  </Link>
                  {poc.author_verified === 1 && <VerifiedBadge size={12} />}
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm font-bold text-zinc-500">
                <div className="flex items-center gap-1.5">
                  <Eye size={16} className="text-zinc-600" />
                  <span>{poc.views}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ThumbsUp size={16} className="text-zinc-600" />
                  <span>{poc.likes_count}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-4 border-t border-white/5">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest text-zinc-600">
                <Calendar size={14} />
                <span><RelativeTime date={poc.created_at} /></span>
              </div>
              <div className="text-xs font-black text-brand uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                View Details →
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
