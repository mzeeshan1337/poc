import { BadgeCheck } from 'lucide-react';

interface VerifiedBadgeProps {
  size?: number;
  className?: string;
}

export default function VerifiedBadge({ size = 14, className = "" }: VerifiedBadgeProps) {
  return (
    <span title="Verified Researcher" className="inline-flex items-center justify-center">
      <BadgeCheck 
        size={size} 
        className={`text-orange-500 fill-orange-500/20 drop-shadow-[0_0_8px_rgba(242,125,38,0.3)] ${className}`} 
      />
    </span>
  );
}
