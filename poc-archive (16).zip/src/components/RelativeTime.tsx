import { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';

export default function RelativeTime({ date }: { date: string | Date }) {
  const parseDate = (d: string | Date) => {
    if (d instanceof Date) return d;
    // If it's a string from SQLite (YYYY-MM-DD HH:MM:SS), convert to ISO UTC
    if (typeof d === 'string' && !d.includes('T') && !d.includes('Z')) {
      return new Date(d.replace(' ', 'T') + 'Z');
    }
    return new Date(d);
  };

  const [time, setTime] = useState(() => formatDistanceToNow(parseDate(date), { addSuffix: true }));

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(formatDistanceToNow(parseDate(date), { addSuffix: true }));
    }, 1000);
    return () => clearInterval(interval);
  }, [date]);

  return <>{time}</>;
}
