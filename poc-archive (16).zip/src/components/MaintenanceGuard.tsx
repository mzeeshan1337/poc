import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Maintenance from '../pages/Maintenance';

export default function MaintenanceGuard({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const location = useLocation();
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkMaintenance = async () => {
      try {
        const res = await fetch('/api/settings/public');
        if (res.ok) {
          const data = await res.json();
          setMaintenanceMode(data.maintenanceMode);
        }
      } catch (e) {
        console.error('Failed to check maintenance mode', e);
      } finally {
        setLoading(false);
      }
    };

    checkMaintenance();
  }, []);

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-brand border-t-transparent"></div>
      </div>
    );
  }

  // Allow admins to bypass maintenance mode, and always allow login page
  if (maintenanceMode && user?.role !== 'admin' && location.pathname !== '/login') {
    return <Maintenance />;
  }

  return <>{children}</>;
}
