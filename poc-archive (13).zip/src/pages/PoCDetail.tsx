import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ThumbsUp, Eye, MessageSquare, Calendar, ShieldAlert, DollarSign, Tag, User, ArrowLeft, Share2, Check, Edit2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatBounty } from '../lib/utils';
import RelativeTime from '../components/RelativeTime';
import CommentSection from '../components/CommentSection';
import VerifiedBadge from '../components/VerifiedBadge';

export default function PoCDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [poc, setPoc] = useState<any>(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [isShared, setIsShared] = useState(false);

  const fetchData = async (skipView = false) => {
    try {
      const pRes = await fetch(`/api/pocs/${id}${skipView ? '?skipView=true' : ''}`);
      if (pRes.status === 404) {
        setPoc(null);
        setLoading(false);
        return;
      }
      if (!pRes.ok) throw new Error('PoC not found');
      const pocData = await pRes.json();
      setPoc(pocData);
      
      const cRes = await fetch(`/api/comments/poc/${pocData.id}`);
      if (cRes.ok) {
        setComments(await cRes.json());
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const handleLike = async () => {
    if (!user || !poc) return;
    
    // Optimistic update
    const wasLiked = poc.is_liked;
    setPoc(prev => ({
      ...prev,
      is_liked: !wasLiked,
      likes_count: wasLiked ? prev.likes_count - 1 : prev.likes_count + 1
    }));

    try {
      const res = await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_id: poc.id, target_type: 'poc' }),
      });
      if (!res.ok) {
        // Rollback on error
        setPoc(prev => ({
          ...prev,
          is_liked: wasLiked,
          likes_count: wasLiked ? prev.likes_count + 1 : prev.likes_count - 1
        }));
      }
    } catch (e) {
      console.error(e);
      // Rollback on error
      setPoc(prev => ({
        ...prev,
        is_liked: wasLiked,
        likes_count: wasLiked ? prev.likes_count + 1 : prev.likes_count - 1
      }));
    }
  };

  const handleShare = () => {
    const shareUrl = `${window.location.origin}/poc/${poc.slug || poc.id}`;
    navigator.clipboard.writeText(shareUrl);
    setIsShared(true);
    setTimeout(() => setIsShared(false), 2000);
  };

  if (loading) return <div className="animate-pulse space-y-8"><div className="aspect-video rounded-3xl bg-white/5" /><div className="h-40 rounded-3xl bg-white/5" /></div>;
  if (!poc) return <div className="text-center py-20 text-zinc-500">PoC not found.</div>;

  const videoId = poc.youtube_url.split('v=')[1]?.split('&')[0] || poc.youtube_url.split('be/')[1]?.split('?')[0];

  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <Link to="/" className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.2em] text-zinc-500 hover:text-white transition-colors">
          <ArrowLeft size={14} />
          Back to Archive
        </Link>
        
        {(user?.id === poc.user_id || user?.role === 'admin') && (
          <Link 
            to={`/edit-poc/${poc.id}`}
            className="flex items-center gap-3 rounded-2xl bg-brand/10 border border-brand/20 px-6 py-3 text-xs font-black uppercase tracking-widest text-brand transition-all hover:bg-brand/20 hover:border-brand/40 w-full sm:w-auto justify-center"
          >
            <Edit2 size={16} />
            EDIT POC
          </Link>
        )}
      </div>

      <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-10">
          {/* Video Player */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="overflow-hidden rounded-[2.5rem] border border-white/5 bg-black shadow-2xl"
          >
            <div className="aspect-video w-full bg-zinc-900">
              <iframe
                src={`https://www.youtube.com/embed/${videoId}?autoplay=0&rel=0`}
                className="h-full w-full"
                allowFullScreen
              />
            </div>
            <div className="p-6 md:p-10">
              <div className="flex flex-col lg:flex-row items-start justify-between gap-8">
                <div className="flex-1 w-full">
                  <h1 className="text-3xl font-black text-white md:text-5xl tracking-tighter leading-tight">{poc.title}</h1>
                  <div className="mt-6 flex flex-wrap gap-3">
                    <span className="rounded-xl border border-brand/20 bg-brand/10 px-4 py-2 text-xs font-black text-brand uppercase tracking-widest">
                      {poc.vuln_type}
                    </span>
                    <span className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-xs font-black text-zinc-400 uppercase tracking-widest">
                      {poc.severity} SEVERITY
                    </span>
                    {poc.bounty && (
                      <span className="flex items-center gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-2 text-xs font-black text-emerald-500 uppercase tracking-widest">
                        <DollarSign size={14} />
                        {formatBounty(poc.bounty)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-6 w-full lg:w-auto justify-between lg:justify-end border-t lg:border-t-0 border-white/5 pt-6 lg:pt-0">
                  <div className="flex items-center gap-6">
                    <motion.button 
                      whileTap={{ scale: 0.95 }}
                      onClick={handleLike} 
                      className="flex items-center gap-3 rounded-2xl bg-white/5 px-6 py-3 text-zinc-300 transition-all hover:bg-brand/20 hover:text-brand border border-white/5"
                    >
                      <ThumbsUp size={20} />
                      <span className="font-black text-lg">{poc.likes_count}</span>
                    </motion.button>
                    <div className="flex items-center gap-3 text-zinc-500 px-2">
                      <Eye size={20} className="text-zinc-600" />
                      <span className="font-black text-lg">{poc.views}</span>
                    </div>
                  </div>
                  <button 
                    onClick={handleShare}
                    className="flex items-center gap-3 group"
                  >
                    <div className={`p-3 rounded-2xl border transition-all ${isShared ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500' : 'bg-white/5 border-white/10 text-zinc-400 group-hover:text-white group-hover:border-white/20'}`}>
                      {isShared ? <Check size={20} /> : <Share2 size={20} />}
                    </div>
                    <span className={`text-sm font-black uppercase tracking-widest transition-colors ${isShared ? 'text-emerald-500' : 'text-zinc-500 group-hover:text-white'}`}>
                      {isShared ? 'COPIED' : 'SHARE'}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Description */}
          <div className="premium-card p-10">
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-zinc-500 mb-6">Technical Overview</h2>
            <p className="whitespace-pre-wrap text-zinc-400 leading-relaxed text-lg">{poc.description}</p>
            
            {poc.tags && (
              <div className="mt-10 flex flex-wrap gap-3 pt-10 border-t border-white/5">
                {(poc.tags || '').split(',').filter(Boolean).map((tag: string) => (
                  <span key={tag} className="flex items-center gap-2 rounded-xl bg-white/5 px-4 py-2 text-xs font-bold uppercase tracking-widest text-zinc-500 border border-white/5">
                    <Tag size={14} className="text-brand" />
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Comments */}
          <CommentSection 
            targetId={poc.id} 
            targetType="poc" 
            comments={comments} 
            user={user} 
            onCommentAdded={() => fetchData(true)} 
          />
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <div className="premium-card p-8">
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 mb-8">RESEARCHER</h3>
            <Link to={`/profile/${poc.author_name}`} className="flex items-center gap-5 group">
              <div className="h-20 w-20 overflow-hidden rounded-2xl border-2 border-white/5 bg-zinc-900 transition-all group-hover:border-brand/50">
                <img 
                  src={poc.author_avatar || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${poc.author_name}`} 
                  className="h-full w-full object-cover"
                  alt={poc.author_name}
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <div className="text-xl font-bold text-white group-hover:text-brand transition-colors tracking-tight">{poc.author_name}</div>
                  {poc.author_verified === 1 && <VerifiedBadge />}
                </div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-600 mt-1">Submitted <RelativeTime date={poc.created_at} /></div>
              </div>
            </Link>
            <div className="mt-10">
              <Link to="/chat" className="flex items-center justify-center gap-3 btn-secondary w-full py-4">
                <MessageSquare size={18} />
                SEND MESSAGE
              </Link>
            </div>
          </div>

          <div className="rounded-[2rem] border border-brand/20 bg-brand/5 p-8 relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center gap-3 text-brand mb-4">
                <ShieldAlert size={24} />
                <span className="font-black uppercase tracking-widest text-xs">Security Advisory</span>
              </div>
              <p className="text-sm text-zinc-400 leading-relaxed">
                This Proof-of-Concept is provided exclusively for educational purposes and authorized security research. Unauthorized use of this information is strictly prohibited and may be illegal.
              </p>
            </div>
            <div className="absolute -right-10 -bottom-10 h-32 w-32 bg-brand/10 blur-3xl rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
}
