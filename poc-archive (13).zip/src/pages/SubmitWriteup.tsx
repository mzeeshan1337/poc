import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FileText, Tag, Info, PlusCircle, DollarSign, Eye, Edit3 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function SubmitWriteup() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    program: '',
    bounty: '',
    tags: '',
    severity: 'Low'
  });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-brand border-t-transparent"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Force at least one image
    const hasImage = /!\[.*?\]\((.*?)\)/.test(formData.content);
    if (!hasImage) {
      alert('You must include at least one image in your writeup content.');
      return;
    }

    const titleWords = formData.title.trim().split(/\s+/).length;
    if (titleWords > 15) {
      alert('Writeup Title must not exceed 15 words.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/writeups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          bounty: formData.bounty ? parseFloat(formData.bounty) : null
        }),
      });
      const data = await res.json();
      if (res.ok) {
        navigate(`/writeup/${data.id}`);
      } else {
        alert(data.error || 'Failed to publish writeup');
      }
    } catch (e) {
      console.error(e);
      alert('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-[1400px] pb-20">
      <div className="mb-12 flex items-center gap-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-[1.5rem] bg-brand/10 border border-brand/20 text-brand shadow-[0_0_30px_rgba(242,125,38,0.1)]">
          <FileText size={32} />
        </div>
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase">PUBLISH <span className="text-brand">WRITEUP</span></h1>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
        <form onSubmit={handleSubmit} className="lg:col-span-2 premium-card p-10 md:p-16 space-y-10">
          <div className="space-y-8">
            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <FileText size={14} className="text-brand" />
                Writeup Title
              </label>
              <input
                required
                placeholder="e.g. How I bypassed MFA on a major e-commerce platform"
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="space-y-3">
              <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                <Tag size={14} className="text-brand" />
                Target Program
              </label>
              <input
                required
                placeholder="e.g. Google, Facebook, Private Program"
                className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                value={formData.program}
                onChange={(e) => setFormData({ ...formData, program: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
              <div className="space-y-3">
                <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                  <DollarSign size={14} className="text-brand" />
                  Bounty Amount (Optional)
                </label>
                <input
                  type="number"
                  placeholder="0"
                  className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                  value={formData.bounty}
                  onChange={(e) => setFormData({ ...formData, bounty: e.target.value })}
                />
              </div>
              <div className="space-y-3">
                <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                  <Tag size={14} className="text-brand" />
                  Severity
                </label>
                <select
                  className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all appearance-none"
                  value={formData.severity}
                  onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical</option>
                </select>
              </div>
              <div className="space-y-3">
                <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                  <Tag size={14} className="text-brand" />
                  Tags (Comma separated)
                </label>
                <input
                  placeholder="web, writeup, exploit"
                  className="w-full rounded-2xl border border-white/5 bg-black/40 p-5 text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="mb-2 flex items-center justify-between">
                <label className="text-sm font-black uppercase tracking-widest text-zinc-500 flex items-center gap-2">
                  <FileText size={14} className="text-brand" />
                  Content (Markdown supported)
                </label>
                <div className="flex items-center gap-4">
                  <button 
                    type="button"
                    onClick={() => setShowPreview(!showPreview)}
                    className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-white transition-colors"
                  >
                    {showPreview ? (
                      <><Edit3 size={14} className="text-brand" /> EDIT</>
                    ) : (
                      <><Eye size={14} className="text-brand" /> PREVIEW</>
                    )}
                  </button>
                  <button 
                    type="button"
                    onClick={() => {
                      const url = prompt('Enter image URL:');
                      if (url) setFormData({ ...formData, content: formData.content + `\n![image](${url})\n` });
                    }}
                    className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-brand hover:text-brand/80 transition-colors"
                  >
                    <PlusCircle size={14} />
                    ADD IMAGE
                  </button>
                </div>
              </div>
              {showPreview ? (
                <div className="w-full min-h-[400px] rounded-2xl border border-white/5 bg-black/40 p-10 text-white prose max-w-none overflow-auto">
                  <ReactMarkdown>{formData.content || '*No content to preview*'}</ReactMarkdown>
                </div>
              ) : (
                <textarea
                  required
                  rows={18}
                  placeholder="# Introduction\n\nDescribe the vulnerability here..."
                  className="w-full font-mono rounded-2xl border border-white/5 bg-black/40 p-6 text-sm text-white focus:border-brand/50 focus:outline-none focus:ring-1 focus:ring-brand/50 transition-all resize-none"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                />
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="btn-primary w-full py-6 text-lg"
          >
            {isSubmitting ? 'PUBLISHING...' : 'PUBLISH WRITEUP'}
          </button>
        </form>

        <div className="space-y-8">
          <div className="glass p-8 rounded-[2rem] border-white/5">
            <div className="flex items-center gap-3 text-brand mb-6">
              <Info size={24} />
              <span className="font-black uppercase tracking-widest">Markdown Tips</span>
            </div>
            <ul className="space-y-4 text-sm text-zinc-500 font-bold">
              <li className="flex items-center justify-between">
                <span>Heading</span>
                <code className="text-brand bg-brand/5 px-2 py-1 rounded"># Title</code>
              </li>
              <li className="flex items-center justify-between">
                <span>Bold</span>
                <code className="text-brand bg-brand/5 px-2 py-1 rounded">**text**</code>
              </li>
              <li className="flex items-center justify-between">
                <span>Code Block</span>
                <code className="text-brand bg-brand/5 px-2 py-1 rounded">```code```</code>
              </li>
              <li className="flex items-center justify-between">
                <span>Link</span>
                <code className="text-brand bg-brand/5 px-2 py-1 rounded">[link](url)</code>
              </li>
              <li className="flex items-center justify-between">
                <span>Image</span>
                <code className="text-brand bg-brand/5 px-2 py-1 rounded">![alt](url)</code>
              </li>
            </ul>
          </div>
          
          <div className="glass p-8 rounded-[2rem] border-white/5 bg-gradient-to-br from-brand/10 to-transparent">
            <h3 className="font-black text-white mb-4 uppercase tracking-widest">Why write?</h3>
            <p className="text-sm text-zinc-500 leading-relaxed font-bold">
              Sharing writeups helps the community learn, builds your reputation as a researcher, and can even lead to job opportunities.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
